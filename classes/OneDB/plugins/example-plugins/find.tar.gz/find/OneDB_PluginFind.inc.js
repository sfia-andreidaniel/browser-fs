window['OneDB_Plugin_Find'] = function( app ) {
    console.log( "OneDB_Plugin_Find( app )" );
};