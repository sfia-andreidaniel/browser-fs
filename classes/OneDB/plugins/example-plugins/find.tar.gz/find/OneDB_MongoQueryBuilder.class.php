<?php

    /* This class is used in order to build a MongoDB collection
       find object
     */

    class OneDB_MongoQueryBuilder {
        
        public $fields = array();
        
        public function __construct() {
            
        }
        
        public function addCondition( $fieldName, $fieldValue ) {
            
            $fKey = reset( explode(' ', $fieldName ) );
            
            if ( !empty( $fieldValue ) )
                $this->fields["$fKey"] = isset( $this->fields[ "$fKey" ] ) ? $this->fields[ $fKey ] : array();
            else
                return; //ignore, field value is not specified
        
            

            $asInteger = FALSE; 
            $asDate = FALSE;
            
            $parts = explode(' ', $fieldName);
            if (count($parts) > 1) {
                switch ($parts[1]) {
                    case 'lt':
                    case 'gt':
                    case 'lte':
                    case 'gte':
                    case '<':
                    case '<=':
                    case '>':
                    case '>=':
                    case 'is':
                    case '=':
                    case '==':
                        $asInteger = TRUE;
                        
                        /* Determine if the value is in date format (YYYY-MM-DD), and if it is, convert it to a unix timestamp */
                        
                        $reg = '/^([\\d]+)(\/|-|\\\\)([\\d]+)(\/|-|\\\\)([\\d]+)$/';
                        
                        if (preg_match($reg, $fieldValue, $matches )) {

                            $asDate = TRUE;
                            $Year = $matches[1];
                            $Month= $matches[3];
                            $Day  = $matches[5];
                            
                        }
                        
                        break;
                    default:
                        throw new Exception("Invalid operator in field name: " . $parts[1] );
                }
            }
        
            switch (true) {
        
                case $asInteger === TRUE:
                
                    switch ($parts[1]) {
                        case 'lt':
                        case '<':
                            if (is_array( $this->fields[ $parts[0] ] ) )
                                $this->fields[ $parts[0] ]['$lt'] = !$asDate ? $fieldValue : mktime( 0, 0, 0, $Month, $Day, $Year );
                            break;
                        case 'lte':
                        case '<=':
                            if (is_array( $this->fields[ $parts[0] ] ) )
                                $this->fields[ $parts[0] ]['$lte'] = !$asDate ? $fieldValue : mktime( 23, 59, 59, $Month, $Day, $Year );
                            break;
                        case 'gt':
                        case '>':
                            if (is_array( $this->fields[ $parts[0] ] ) )
                                $this->fields[ $parts[0] ]['$gt'] = !$asDate ? $fieldValue : mktime( 23, 59, 59, $Month, $Day, $Year ) + 1;
                            break;
                        case 'gte':
                        case '=>':
                            if (is_array( $this->fields[ $parts[0] ] ) )
                                $this->fields[ $parts[0] ]['$gte'] = !$asDate ? $fieldValue : mktime( 0, 0, 0, $Month, $Day, $Year );
                            break;
                        case 'is':
                        case '=':
                        case '==':
                            if (!$asDate) {
                                if (is_array( $this->fields[ $parts[0] ] ) )
                                    $this->fields[ $parts[0] ] = $fieldValue;
                            } else {
                                $this->fields[ $parts[0] ] = array(
                                    '$gte' => mktime( 0, 0, 0, $Month, $Day, $Year ),
                                    '$lte' => mktime( 23, 59, 59, $Month, $Day, $Year )
                                );
                            }
                            break;
                        default:
                            throw new Exception("Unknown operator: " . $parts[1]);
                            break;
                    }
                
                    break;
        
                // in order to search for empty fields, put a "!" sign (meaning is empty)
                case $fieldValue == '!':
                    $this->fields["$fieldName"]['$ne'] = '';
                    break;
        
                default:
                    if (strlen($fieldValue) > 1)
                        $regex = $fieldValue[0] == '%' ? '' : '^';
                    else
                        $regex = '';
        
                    for ($i=0; $i<($len = strlen($fieldValue)); $i++) {
        
                        switch (TRUE) {
                            case $fieldValue[$i] == '%':
                                $regex .= '([^*]+?)?';
                                break;

                            case preg_match('/^[\s]$/', $fieldValue[$i]):
                                
                                switch ($fieldValue[$i]) {
                                    case "\n":
                                        $regex .= '\n';
                                        break;
                                    case "\t":
                                        $regex .= '\t';
                                        break;
                                    case "\r":
                                        $regex .= '\r';
                                        break;
                                    default:
                                        $regex .= '\s';
                                }
                                
                                break;
                            
                            // escape regex special chars...
                            case in_array( $fieldValue[$i], array('(', '{', '}', ')', '/', "\\", '-', '+', '?', '^', '$', '*') ):
                                $regex .= ( "\\" . $fieldValue[$i]) ;
                                break;
                            
                            default:
                                $regex .= addslashes( strtolower( $fieldValue[$i] ) );
                                break;
                        }
                    }
                    
                    if (strlen($fieldValue) > 1 && $fieldValue[ strlen($fieldValue) - 1] != '%')
                        $regex .= '$';
        
                    $this->fields["$fieldName"]['$regex'] = $regex;
                    $this->fields["$fieldName"]['$options'] = 'i';
                    break;
            }
            
        }
    }

    /*
    $qb = new OneDB_MongoQueryBuilder();
    $qb->addCondition('nume', 'andrei%');
    $qb->addCondition('prenume', '%andrei');
    $qb->addCondition('prenume2', '%an&^^&*(drei%');
    $qb->addCondition('age lt', 4);
    
    //$qb->addCondition('age is', 3);
    $qb->addCondition('age is', '2012-01-01');
    
    print_r( $qb->fields );
    */

?>