window['OneDB_FindPanel_ResultSet_cmd_send_mail'] = function( app ) {

    app.handlers.cmd_send_mail = function() {
        
        var senders = [];
        
        var sel = app.grid.selection.byRows;
        
        if (sel.length) {
            for (var i=0; i<sel.length; i++) {
                if (sel[i].email)
                    senders.push( {
                        "email": sel[i].email,
                        "firstName": sel[i].firstName,
                        "lastName": sel[i].lastName
                    } )
            }
        } else {
            for (var i=0; i<app.grid.rows.length; i++) {
                if (app.grid.rows[i].email)
                    senders.push({
                        "email" : app.grid.rows[i].email,
                        "firstName": app.grid.rows[i].firstName,
                        "lastName": app.grid.rows[i].lastName
                    });
            }
        }
        
        if (!senders.length) {
            alert("Eroare: Nu am găsit nici măcar o singură adresă mail in selecţie");
            return;
        }

        var dlg = new Dialog({
            "width": 600,
            "height": 400,
            "caption": "Trimitere Email",
            "childOf": app,
            "modal": true
        });
        
        dlg.document = {
            "editorHeight": 160
        };
        
        dlg.insert( new DOMLabel(
            'De la: ', {
                'x': 10,
                'y': 10
            }
        ) );

        dlg.insert( new DOMLabel(
            'Subiect: ', {
                'x': 10,
                'y': 30
            }
        ) );

        dlg.insert( new DOMLabel(
            'Şablon Mail: ', {
                'x': 10,
                'y': 50
            }
        ) );
        
        dlg.fromField = dlg.insert(
            (new TextBox('')).setAnchors({
                "width": function(w,h) { return w - 100 + 'px'; }
            }).setAttr(
                "style", "position: absolute; left: 90px; top: 2px"
            )
        );
        
        dlg.subjectField = dlg.insert(
            (new TextBox('')).setAnchors({
                "width": function(w,h) { return w - 100 + 'px'; }
            }).setAttr(
                "style", "position: absolute; left: 90px; top: 22px"
            )
        );
        
        dlg.templateField = dlg.insert(
            (new DropDown(
            )).setAnchors({
                "width": function(w,h) { return w - 92 + 'px'; }
            }).setAttr(
                "style", "position: absolute; left: 90px; top: 44px"
            )
        );
        
        dlg.templateField.setItems( app.onedb.$_PLUGIN_JSON_POST( '%plugins%/find', 'get-mail-templates', [] ) );
        
        dlg.insert($('div').setAttr(
            'style', 'display: block; height: 80px'
        ));
        
        /* Insert the editor interface */
        var docHTML = dlg.insert(
            ($('div', 'tinyMCE_document')).setAnchors({
                "width": function(w,h) {
                    return w + 'px';
                },
                "height": function(w,h) {
                    return h - 100 + 'px';
                },
                "dummy": function(w,h) {
                    try {
                        dlg.body.getElementsByTagName('table')[0].style.height = h - dlg.document.editorHeight - 40 + 'px';
                    } catch (e) {}
                }
            })
        );

        docHTML.id = editorID = "tinymce_" + (new Date()).getTime() + "_" + ((10000 * Math.random()) << 0);

        Object.defineProperty(
            dlg,
            "editor",
            {
                "get": function() {
                    return tinyMCE.editors[ editorID ];
                }
            }
        );

        tinyMCE.execCommand( 'mceAddControl', false, docHTML.id );

        Object.defineProperty(
            dlg,
            "editorID",
            {
                "get": function() {
                    return editorID;
                }
            }
        );

        dlg.closeCallback = function() {
            tinyMCE.execCommand('mceFocus',         false, dlg.editorID );
            tinyMCE.execCommand('mceRemoveControl', false, dlg.editorID );
            console.log('Removed editor instance!');
            return true;
        }
        
        dlg.insert(
            (new Button('<b>Trimite</b> <span style="color: #666">(la <b>' + senders.length + '</b> contacte)</span>', function() {
                dlg.sendMails();
            })).
                setAttr(
                    "style", "position: absolute; left: 5px; bottom: 5px"
                )
        );
        
        dlg.templateField.onchange = function() {
            if (dlg.templateField.value == '') return;
            var req = [];
            req.addPOST('templateID', dlg.templateField.value);
            var tpl = app.onedb.$_PLUGIN_JSON_POST( '%plugins%/find', 'fetch-mail-template', req );
            
            tpl = tpl || {};
            
            dlg.subjectField.value = tpl.name || '';
            dlg.editor.setContent( tpl.data || '' );
        };

        dlg.sendMails = function() {
            
            var req = [];
            
            req.addPOST('body', dlg.editor.getContent());
            req.addPOST('senders', JSON.stringify( senders ));
            req.addPOST('subject', dlg.subjectField.value );
            req.addPOST('from', dlg.fromField.value );
            
            if (app.onedb.$_PLUGIN_JSON_POST( '%plugins%/find', 'sendmail', req ) == 'ok' )
                alert("Am trimis cu succes mesajul!");
            
        }

        // End of inserting

    }
    
}