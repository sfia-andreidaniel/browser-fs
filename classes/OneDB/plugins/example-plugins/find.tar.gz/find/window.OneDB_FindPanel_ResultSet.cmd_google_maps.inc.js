window['OneDB_FindPanel_ResultSet_cmd_google_maps'] = function( app ) {

    app.handlers.cmd_google_maps = function() {
        
        var dots = [];
        
        var sel = app.grid.selection.byRows;
        
        if (sel.length) {
            for (var i=0; i<sel.length; i++) {
                if (sel[i].latitude && sel[i].longitude)
                    dots.push( {
                        "latitude": sel[i].latitude,
                        "longitude": sel[i].longitude
                    } )
            }
        } else {
            for (var i=0; i<app.grid.rows.length; i++) {
                if (app.grid.rows[i].latitude && app.grid.rows[i].longitude)
                    dots.push( {
                        "latitude": app.grid.rows[i].latitude,
                        "longitude": app.grid.rows[i].longitude
                    } );
            }
        }
        
        if (!dots.length) {
            alert("Eroare: Nu am găsit nici măcar o persoană pe care să o plasez pe hartă");
            return;
        }
        
        window.appl = app;
        
        if (typeof app.onedb.plugins['%plugins%/google_maps'] == 'undefined') {
            alert("Plugin-ul Google Maps (%plugins%/google_maps) nu a fost detectat!");
            return;
        }
        
        app.onedb.plugins['%plugins%/google_maps']['plugin.json'].plugin.sheetInstance.fullScreen = false;
        app.onedb.plugins['%plugins%/google_maps']['plugin.json'].plugin.sheetInstance.dettached = true;
        
        app.onedb.plugins['%plugins%/google_maps']['plugin.json'].plugin.sheetInstance.cluster = dots;


    }
    
    //window.app = app;
}