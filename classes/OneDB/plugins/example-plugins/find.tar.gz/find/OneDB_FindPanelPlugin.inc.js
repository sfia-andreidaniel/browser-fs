window['OneDB_FindPanel_Plugin'] = function( ) {
    console.log( "OneDB_FindPanel_Plugin", arguments );
}