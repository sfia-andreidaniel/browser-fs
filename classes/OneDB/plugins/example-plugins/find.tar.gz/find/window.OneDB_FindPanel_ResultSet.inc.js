window['OneDB_FindPanel_ResultSet'] = function( results, onedb ) {

    results = results || {};
    
    if (typeof results['fields'] == 'undefined' || typeof results['data'] == 'undefined') {
        alert("Serverul a întâmpinat o eroare la căutarea de date!");
        return;
    }
    
    if (!results.data.length) {
        alert("Serverul nu a găsit nici un rezultat!");
        return;
    }
    
    var dlg = new Dialog({
        "width": onedb.width - 50,
        "height": onedb.height - 50,
        "caption": "Rezultate căutare",
        "y": 15,
        "childOf": onedb
    });
    
    dlg.onedb = onedb;
    
    dlg.handlers = {};
    dlg.appHandler = function( cmd ) {
        if (typeof dlg.handlers[cmd] != 'undefined')
            return dlg.handlers[ cmd ]();
        else
            alert("Command not implemented: " + cmd );
    }
    
    var toolbars = [
        {
            "name": "Export",
            "items": [
                {
                    "caption": "Excel",
                    "id": "cmd_excel",
                    "icon": "data:image/gif;base64,R0lGODlhIAAgAPcAAAAAAPv8//r7/vf5/qy93sLL3ejv/e7z/fL2/vz9/9zn+9/p++Ps/PD1/u/0/fP3/mad82uf8XGi8Hmm7ZWz5KW73qm+4c3e+dHg+dPi+tDe9dXj+tfk+tjl+tzo+9/q/OTu/+Hr/ODq++Tt/Ofv/Onw/Ovy/erx/O3z/fD1/YGr6oeu6I6y5Y6r1ZOv2Ju44qC636rC5K7E5LnO7Mnc+cPU7s/g+tnm+trn+t/q++Ls++Xu/OTt+/P3/fn7/mqKtoem0Yqp04yq1I+t1pKv15Sx2ZOw2JWy2Zay2Zez2pm125y33Zy43Zu23J653p+63qK84KS+4aO836fA46a/4qvE5a7G563F5qzE5bHJ6LXK573S7palurPE3Jinu56twau5zKq4y6m3yq+90PH2/ff6/nSGnLPL6ZyrvqGww6a1yLG/0a+9z627zfX5/qOzxTBIYDJKYjdOZj1Ua0pgd19ziPP4/fr8/v3+//v9/Onx6tvq3ANoA9rp2tno2djn2N/s397r3uHt4eTv5Obw5uny6ejx6O317evz6+/27/H38fT59PP48/b69vX59fb59vj6+P7//v3+/fz9/B13HEyWSjSHMWOZYFmkVGisY1mCVt3q3EaTP0iHQW6wZ+Pu4i9RK2SqW12aVnS2bHu7coXBe5zHlLLWqqfQnXWyYoq1e5C8gZW3inagZXuma4CqcIWvdU6MNF6TSGqWV2aOVHGbXo2qgSlMGTdcJVaMPEtyOTBSHUZsMmGHTEFlK1Z6QFyARvr7+f////7+/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAAAALAAAAAAgACAAAAj/AAEIHEiwoMGDCAWuWbhmDJuHbdqAARNGjBg1GBMWXCOso8ePeIThwZMggRozCFepgvXKVatas2j16gXs1y9dukaOLPkGRJ2Dqk6dQoXKlFFWKlm2zLkzQYCeHuYYDNoxkqQ8wSA1WqQo0aFWumbM2BkgDQgPGuQUhHVqmKSrWR9x9YoIrE6SAb6c1VADDsFXqIZ5ypRJ1CNGmhJrKlSLV1OnX7bM0CLDgl+BrlBNqnSKFClZmjxhssSHUOMzWbJYuVIFTZ3XdOjMudzKFFZOqEaF6jS69KBZvkZacXrHR4EuFZJLuVzLVLBGjiyZCoWJV+lPgoCPrOLUR5kobh6Q/3EA4/IsVtAZjV4lqxKuS5cAycKFJUaMKVSiQIHxAEGKA+UJRMsqXGGSCiaUlNIeLrZsMh9JVAQgQBllONEDAg6g8MJlvaiiHigggkLJKAvuMV9JUQjgnRtLINDAASZsKBAwsNBViCGD2BIiKH3ksksU+sHgBBNNKEHGASicQMFlv7xyCCJ6EDLIJ4AEssceffzho4RPlDGAGz0kkeEJJSwp0C+uIGKIlFQGsskefvzxRyy3+OADE1/2QEYRKJhgwA4sXKaLSy/BNIssiOaSSyx0OrFEkUkcUYQLJpRgwAiBCoSTLrx06sunuIS6y6i3fJmEeCn0WQIJIzCwwmUFff9BIRUDDOAlnuH1l4IDRAzxAwk7MJCDCrAS9IUbbgQ5ZJEPIFHED0gO4cYPI+ggggfEHvSFHT3w90APPRiZQhHTJtnCtCFcq8AExQ6EBgJkOEEGGQ2kgIQDBxAxbQtCBDHtBx7g0AG7B6HhgAOPKhFpEUSYIO0PO/Dg7w8Bd7CBBO0KhAYKKChhwscnEFFCCef+wEAIQEx7AwcbZIDxQV6QmcTIlg6xww5C/LtAyj+wnIENEWQMgBckkFCEEb22wO8PTDftNAY2AC20FyPwUPXJ1uawgAcBr8xBBhlAfQENEAjNRQhoh6D11h4ocIPXLYs9Ntlmf3AcATBQwMLee68gsIIKKkwwgQQSRADB4WbXIZscccDh+OOQRw65RpRXHhAAOw==",
                    "handler": dlg.appHandler
                }
            ]
        }
    ];
    
    var grpContact = [];
    
    if (results['fields'].indexOf('email') >= 0) {
        grpContact.push({
            "caption": "Email",
            "id"     : "cmd_send_mail",
            "icon"   : "data:image/gif;base64,R0lGODlhIAAgAPf/ACIdHcSvit/PtS0mJjEqKk5FRSYhIWliYrqrmTkyMuHXwkE6Op+Rh83EunVubh4ZGZaGcgwJCRoVFWZfX1pRUZaJgSolJQUCAhEODhUSEgkGBvz48/737f325P7z3f/02v/z2P736/726f315P336P326Pz59/757/315v703//z0t7Pt/325v348P713//y0v/x0P/y1f7x1f/w0OTPof726+7o2+PPpP/yz/335vDp3ereyf7z3+jYvf7z1/fpwv/pt56Rifz58+/p4OPVvtjLsuzXq+HQrvTny//wz5uTkPz6+WNcXOHQqPHo2OXPoHdwcPz37/Lo1/bpyauglNnMtOnYtlJJSW1mZvz690U8PPHo3P/y2j02NvHo2nBpad/NtPLo0/Tpz/Xlwvz7+/TnzfLn00g/PxMQENnS0ldOTt7Nrfr39/fmxPXx7s3DsuHPsP/vzZ2Oc/bjr5yLdeXf1KOMbKCRgpuSjoJyY+3q5uDSq3t0dJiLgbmuoNDDsUpBQdDCqygjI+HWwMzFw/f08uDTuX53d1VMTPvtzV1UVBcUFD84OKuion94eOLVu/jlub6yp/3w0rGloO/r5qCRf6yXd62aeszGxfDdr+DIm8q1kWBXV/jpu5mMgvTu5y8oKJR/UZODbpuHap2Jar+voOTVuf/12FBHR+DQpeXQpJuJcPfpvpiJdffnsMO4sPDr4f701ejawZSDc//00rumir+vmruwor2xoIhvT2tkZOLNp2BZWfv16rKmnbSgh+rZsbenklxTU83Crp2Vkp2VlIp7Z/Du7OHOqKmhntzMsdXCmtvFnO3p5O7r5fXo0OHQqpeHeJSFd93Rtnpzc/nksuXVqOzfyZyOhfblx93Kovbmx/rx2eLTuezVrene0tDGte3ewu3q6Pns0JeIdPnu0tK+l0xDQ9DCr/vmtPnt0oN6evr379/NsvbpwfXlsOHYxs3FwOzcwf/z1XJra/f08JaHderfyZZ+Z3x1dfvy2vTmy/z59f304v79/f///yH5BAEAAP8ALAAAAAAgACAAAAj/AP8JHEiwoMGDCBMqXMiwocOHCQkQADVggAVBBgwA2PigowQJGTKgwYAhgkkNGi6ovPAvgT82hdwcowRLh80tXpxICWNGTJl9U7Jta/PDHatOkIyw7FKvxYYN/KI+bXGCQ4gaJUiw6NAvhQsPH0D4kPFihjeWCz75ExLVRFQhG1pwsCqCBIoR/fp9DTv2BRArGv5pqTDGnwkTWQ7ze1o1hIgSd7nuBQFCxt9cEf6deUUsmQh/S5a4Xdz4cY4RksFSrvZLjqXM5+o4I6SksL/Ei+VeLZFja1ewSeaIshUoAIZ/BYZETVOsERB/UkvzRq3Xw7taEBBUkbXp+JUhUE2I/8OkBMjnDdIj90viilypYUWImDKH5p8a8Gz5mdCjZNIPf3M5Zhde6QTTCi7oTENEOPIwk8E/FOjgFFRRNRMPHv/tplUHa9hzyx/xDXINEolos8g/imxxwoRPbeCPMkH48kNdKCSCQDSXvFGEAvcgMY4kKtwgwT+ceDHXCSue4E8PQRzTAANL6JOJNH40kEcACuyARDkqqDDDDQ/8w4QTIcw115JB+OOYDVQwQEUk4FQBjzHLPKOOCi+oAAOY/0wgRQ0hBErGI9j4U8NjJNig6A6M2vDNLKqoEENZewLwzwFhlCDCZwJU4A+iA3LFA1gfcOMPHanEoCcONFiKhRkkkN1AhiGe+JOVXSxQ19WoYZ3iDwTWzAADqwb884UYLPjTTR/+5IACCrnqmgKvXIglgz+rWINDEjQU60AZS97hT7SocZXXtKRSJkMM8/gzihFxPGHBP1BE0YO4HeRr7rlfpQtCLJO+AAM7pBjxxAD/8DFFJf7k5XBXXnkg8QfVijWplzjQ0osdmiB8CD5RrCDyyCKDAYYA7cBxxMp7QNNEE8jscgMNNAATCgH/rONIPtRA4QA9X2ChywETMMELJ8JQoAYiV6BSACBnaLEAI10kkADOEGWt9dZcd+311wMFBAA7",
            "handler": dlg.appHandler
        });
    }
    
    if (results['fields'].indexOf('phoneMobile') >= 0) {
        grpContact.push({
            "caption": "SMS",
            "id"     : "cmd_send_sms",
            "icon"   : "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAEZ0FNQQAAsY58+1GTAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAT+SURBVFjDrZULUJRVFMcRHzlJ4uSgFkqa+EitSVdCqdFUDBCTTWZ9IA9FFkRScxh5iRmPRUyZFEFACUWdynyUjY4yBIJMM41lmiJqg4kjIgjyXIRdcv7dc/f7dr9vRdRPd+Y3555zz/nvf/fu3s8GgA3hqQkeog6KKAz8Ih5KoXnSETWfBfPCJ2h14cGCMuQcL8DXeYfNUG3C5JlmJk/35FBd2kdzVCMdRQb818ZCl3MI4fGpcjamImprJuLScsxQHr5xy2Posg+CdBQZWPZ5DFYxkdk+/oqhedJRZGBpRDRWxaUgYsd5xYSxedJRZGDJqg0Ii9Vh77l2xdA86SgysCgsEqExOuwp1TPardBL6von1PRsPhmko8iARrse2uhkZJfokXOWUWJBVjtrtX/WtE9oo5NAOooM+AavgzYqEVnFbWayJWRJYlY3dSKEzZOOIgPq5WuwckMCdv/aKtBmoajNVCsSa9J9y5rmSUfpRYSVkV8hkwmaaLOi9anr4MjNdBEpMzDfLxTL129CekELZ+fpFuww0ywgzS3r9IJWThC7jucvDVVmwGtxCILWxUP3UyNSOE3Q/dzIoVysS6OFJk7guo0gHUUGPDQrELA2DknHHiCZkWRFsiRaI/YErIkD6SgyMHdhEPzZNZp4pJ7RwEkQ4OsfGyR70p56c9+yiBiQjiID7uoA+K2Olj3hnhe/8Ci4+wQoMzBrwTJ+jb4I2pjt8A2JRsaZ6g8OlNaML75wx+6ZDcz0XoLFoZE90pBvi+bvbF4aMgMzvDTQhKzH6YorOHzqJIdyae3+t32A+h9M/BulDGG+6VAvuYEPP/Hl12hgiBZTVC4cyqW12tw+uJ/VC12XAtF1biKMjC6RsgkwCnTJmCjUqG8CnyGNBwds5Qbc3NVYuHxtj9Rk90NNvrPJxEU/GEvegbF0vCnytSkaSi25QdwrGc+h2fvfj0H9PisD0+f4QB0YITsCyqW127v6o/GoM6p2j8K9DGbiTzWMRWNhLB4LA1EkxO4oGofaDFvc3fc2Go+NQV1ub7kB148/xQL/cNkRUC6tVW5/FZ2Fzmg+Phq3Mkei+htbGM97w3BuKvtqBcqm8lzEKMTqHbZs5i20nBjNNe7m9JUbcJnhjfl+YT1yI9UOnWdGoYPRdGQkbu1yQtW23ui68Bm6/vAWmIf/zGsTVdv64PpWJ9QdHMlnSeNORj+5gSkfecF7SajsCCiX1iqSBuLhKSc8POnEY23+CFzfMhyVur54VB6MR1cf52YKe/PU4bibOwIdbK6DzVGs2vmKlQE3D8xbpJUdAeXS2tXEgWg/4WjiF0fU7R+K8sRhuL7TFTcS+nL+ERDX11IceQ/1inPEzbT+cgPvT5sLT83KHrmy2R7tx4dBz6jNc0BlmgP7Sy7Gnaw3UKF708w1CdVsj36sN1lvHZuheeKaboDcwHuu7vDwXSE7Asqltctf2kN/xAH3cgezH+RgGNn5Nu+3Q+3eIbidPrRbaI96DL/N5TM0SxpXk16TG3jXZQ57GsbKjmD1pq0csfb3pkG4t+d1lCcMgvH3mWjKG9AtzU/AUDaHz5LG5c0DTQbYy4kxbswk18JJqtmYNHWWBRUx27wmA4ShTIX2o8MU0Vnmxk1cire3fAPs5cCY9hR86M3/irPHxTgxWtbS/GIsywnznlATesRIH9zmuZ7dzKhKpfJ8Eaw+lMP/nZOja8Guaa0AAAAASUVORK5CYII=",
            "handler": dlg.appHandler
        })
    }
    
    if (results['fields'].indexOf('latitude') >= 0 &&
        results['fields'].indexOf('longitude') >= 0
    ) {
        grpContact.push({
            "caption": "Plasează punctele pe Google Maps",
            "id"     : "cmd_google_maps",
            "icon"   : "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAABgRJREFUeNqkV2tsU2UYfk7va7e1u7Vj97ELbMMxQkhgeGECYiSBgQyNim6JYmJiVn5g9AeX+QMiGAv+MUEjiEpCdGEMgqhMNknkhygwGROUbWyyrttKb2vXdj3n+H2n7aFla9fB27z5zuV7z/u8z/e+7/eV4XkeDMMgEanefqrxo6bqZ1ZWZq4iNkXEEGz7Gfh27QlPGSDaSbTL0PfPsUS+ycwGgDjVkcFItDk9TaMrzdfiwLYqaJQyIGTH/XQB7ImTYD1ucE4nAmNj4DxuO3l1mOghAsb+SACI83oyHM3KTNbl5+qgVMphs3tQW5KKN9cUigAkZJxseBmMawIStRpSrY4CwNTwMFi7jTpvIiDa5gSAODcpFTJjcWEG1GoFRsdcsBBlWU54/0PL00hWywVbah1oPwvv7uBSMAoFpOkZkGVmgZtwYeruAHiWpUzseNiPJEbkR5OS5MaF5QZ4fQH8dXMYwyMO0TmVSz1jUTbSZUvFa97vR2DEDF9vD7nhoCgrB5OUZLTMLzs6KwAaeZJK3lhSlIl7ZjuG7tnAcUGWIvVaX/SyMjk50+YQQ0wNDoK1WqEoJDmrUjUSEKaYAKzj4/XleSnGwoJ0mC0O2B2TwjLPpCN27wwLOvNk1nYfAYsF8ux5xKOUMlE/DYB1bIxmu2nFIoOw3k6nD0yc3/U+R5Rv9sofccuNcznBuScgy0intyYCgvqDLGKOkWRz0fJSHU509AOJtQZRAmfOCtE6FRL8nS5HL1F6TaXivh+5EywZ7ZDp9ZCoVEWc10tLe28kgGZGIkFlngY1xVpc73fEdViak/wgOrMZ3/13Bcc2GgTHsSTVz2GtmYXxdhr0/eZmEcD46Gg9QS9QQsty27MFuP7ljbgAnqzKEhLN6XOj4deP0VMjn5Ulp0KK1kIpzlVpsfWyT9eRUVkvcPTJ6Tsb6cc4Llhmi4u02LmpLGYClpHot6zME5xvbduDm+MDMeeKCp5yJZSlz+PC8eo01G/QbxQYOPv7SM0QWad9ry2ERhVcleeW6JGSJMNn5/thsfvEKNYtMeCd9SWwTdnw1vkD6LEOiB1R7AOERZ4EQxX0mueiEzYwBZlSRS9rhE64+O02PjVZBYWMwabl87C2Rg+DTil2uTsWD9xeFiUk8mQC0OV3o/bbdwUGQi5Jp+MIg2zQqRBtfJHI5OAoEDGRCBC3j8U3XUOCUkcl2RrhnUGnws7N5WKk39/qEkDw1CHLCo7nKnzIRhZJW+SeQMF033UK1wfrCqKM7ZMuBHxeweZRJWwb1QmZGBphJRhuWbAKKQo1HkseBsDHaaUjJAmFxArNzU/Vo/XFfcL4uBIGMBDccKJ9U/H7AzCduoWJyUCUYVVWMX5+9VPU5j3xOP4HwgA6OZLFkb2eAspLU6AqPwVPVWbiat/0Q02qUoPWhv14qXLNowK4Fk7CrgDLNVZkq7G6OgvzSfYvyk8OlqFvmNAwTK4nAAfZI1S5gDI36iuH1xmhVWlw5M/TcwVwOgyg7esdS015mWodz7qA+x1gbl8EbL+I6x6Z75Li98HkvhH1pQ9XbYeD9IWTPRcSdU4pbROPZGQ7NjHWdiNz9yBpVa7ZT7MZqyEt3w9Grg1WSmhfWPZFkwAkATnm2tXZFFmGLUzfbnsizgVGrB1guwkLAWdUTjxfuiLR6HdElWFGVhZ92DKnUnb3gr31QdSz2vzqRExbSPT2aY0o7YV7hyg1cwHBWS+As5wS7wtm7w2U+kPxTsWUmmtzBRGWQedo3LILUx8TAGGBUlNHMzTx89iDvPltqDvWLPq9ujD1YZHNNDMEYpPtXO5eMu6ZtSI0C4MnHpL95/+9HGvN98ZrxYgBhBoVk0r9Km4/zwv2hOYfTdElyOM40eJYzuP9NaPM0CML3fJSqDbUqSs2rFStX1ahqDOkSXPEf0QL9kNq2IzPr7ZjV+cR8C6/mR1yXAz0jJ2b6h7tJVNcIfUQnaQLFtnXYgGQhEAoQkDCYMKa9N4rKQXZuSUaZt7rDDlN819cavXcaL00SN55Q848EU7pMz/RqeDB8IH8L8AAl3WJf/AvVy8AAAAASUVORK5CYII=",
            "handler": dlg.appHandler
        });
    }
    
    if (grpContact.length) {
        toolbars.push({
            "name": "Contact",
            "items": grpContact
        })
    }
    
    dlg.toolbars = toolbars;
    
    var grid = dlg.insert(
        (new HyperDataGrid()).setAnchors({
            "width": function(w,h) {
                return w + 'px';
            },
            "height": function(w,h) {
                return h + 'px';
            }
        })
    );
    
    var captions = {
        "firstName": "Nume",
        "lastName": "Prenume",
        "sex": "Sex",
        "birthDate": "Data Naşterii",
        "age": "Vârsta",
        "studies": "Studii",
        "idSerial": "CI.ID",
        "idNumber": "CI.Număr",
        "idPersonalCode": "CI.CNP",
        "branch": "Judeţ",
        "city": "Oraş",
        "street": "Stradă",
        "number": "Număr",
        "numberBlock": "Număr Bloc",
        "numberLadder": "Scară",
        "numberFloor": "Etaj",
        "numberAppartment": "Apartament",
        "addressType": "Tip Clădire",
        "isCompany": "Tip Adresă",
        "latitude": "Latitudine",
        "longitude": "Longitudine",
        "phoneFixed": "Telefon Fix",
        "phoneMobile": "Telefon Mobil",
        "email": "Email",
        "activeVoter": "Votant Activ",
        "party": "Partid",
//         "colleague": "Colegiu",
        "school": "Şcoală",
        "section": "Secţie",
        "misc": "Diverse",
        "projects": "Proiecte"
    };
    
    /* Dinamically build grid columns */
    for (var i=0; i<results.fields.length; i++) {
        grid.createColumn({
            "name": results.fields[i],
            "type": "string",
            "resizeable": true,
            "visible": results.fields[i] == '_id' ? false : true,
            "caption": captions[ results.fields[i] ] || results.fields[i],
            "width": 100,
            "sortable": true
        });
    }
    
    grid.selectable = true;
    
    for (var i=0; i<results.data.length; i++) {
        grid.rows.add( results.data[i] );
    }
    
    dlg.grid = grid;
    
    window['OneDB_FindPanel_ResultSet_cmd_excel']( dlg );
    window['OneDB_FindPanel_ResultSet_cmd_send_mail']( dlg );
    window['OneDB_FindPanel_ResultSet_cmd_send_sms']( dlg );
    window['OneDB_FindPanel_ResultSet_cmd_google_maps']( dlg );
    
    window.g = dlg.grid;
    
    return dlg;
};
