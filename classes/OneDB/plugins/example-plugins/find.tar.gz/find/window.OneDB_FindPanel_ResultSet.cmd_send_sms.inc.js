window['OneDB_FindPanel_ResultSet_cmd_send_sms'] = function( app ) {

    app.handlers.cmd_send_sms = function() {
        
        var senders = [];
        
        var sel = app.grid.selection.byRows;
        
        if (sel.length) {
            for (var i=0; i<sel.length; i++) {
                if (sel[i].phoneMobile)
                    senders.push( {
                        "phoneMobile": sel[i].phoneMobile,
                        "firstName": sel[i].firstName,
                        "lastName": sel[i].lastName
                    } )
            }
        } else {
            for (var i=0; i<app.grid.rows.length; i++) {
                if (app.grid.rows[i].phoneMobile)
                    senders.push({
                        "phoneMobile" : app.grid.rows[i].phoneMobile,
                        "firstName": app.grid.rows[i].firstName,
                        "lastName": app.grid.rows[i].lastName
                    });
            }
        }
        
        if (!senders.length) {
            alert("Eroare: Nu am găsit nici măcar un numar de telefon mobil in selecţie");
            return;
        }

        var dlg = new Dialog({
            "width": 300,
            "height": 250,
            "caption": "Trimitere SMS",
            "childOf": app,
            "modal": true
        });
        
        dlg.insert( new DOMLabel(
            'De la: ', {
                'x': 10,
                'y': 10
            }
        ) );

        dlg.insert( new DOMLabel(
            'Şablon SMS: ', {
                'x': 10,
                'y': 30
            }
        ) );
        
        dlg.fromField = dlg.insert(
            (new TextBox('')).setAnchors({
                "width": function(w,h) { return w - 100 + 'px'; }
            }).setAttr(
                "style", "position: absolute; left: 90px; top: 2px"
            )
        );
        
        dlg.templateField = dlg.insert(
            (new DropDown(
            )).setAnchors({
                "width": function(w,h) { return w - 92 + 'px'; }
            }).setAttr(
                "style", "position: absolute; left: 90px; top: 24px"
            )
        );
        
        dlg.templateField.setItems( app.onedb.$_PLUGIN_JSON_POST( '%plugins%/find', 'get-sms-templates', [] ) );
        
        dlg.insert($('div').setAttr(
            'style', 'display: block; height: 80px'
        ));
        
        dlg.editor = dlg.insert(
            $('textarea')
                .setAnchors({
                    "width": function( w, h ) {
                        return w - 14 + 'px';
                    },
                    "height": function( w, h) {
                        return h - 90 + 'px';
                    }
                })
                .setAttr(
                    "style", "position: absolute; left: 5px; top: 50px"
                )
        );
        
        dlg.insert(
            (new Button('<b>Trimite</b> <span style="color: #666">(la <b>' + senders.length + '</b> contacte)</span>', function() {
                dlg.sendSMS();
            })).
                setAttr(
                    "style", "position: absolute; left: 5px; bottom: 5px"
                )
        );
        
        dlg.templateField.onchange = function() {
            if (dlg.templateField.value == '') return;
            var req = [];
            
            req.addPOST('templateID', dlg.templateField.value);
            var tpl = app.onedb.$_PLUGIN_JSON_POST( '%plugins%/find', 'fetch-sms-template', req );
            
            tpl = tpl || {};
            
            dlg.editor.value = tpl.data || '';
            
        };

        window.sms = dlg;

        dlg.sendSMS = function() {
            
            var req = [];
            
            req.addPOST('body', dlg.editor.value );
            req.addPOST('senders', JSON.stringify( senders ));
            req.addPOST('from', dlg.fromField.value );
            
            if (app.onedb.$_PLUGIN_JSON_POST( '%plugins%/find', 'sendsms', req ) == 'ok' )
                alert("Am trimis cu succes mesajul!");
            
        }

        // End of inserting

    }
    
}