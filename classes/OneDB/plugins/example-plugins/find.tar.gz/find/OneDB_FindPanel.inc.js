window['OneDB_FindPanel'] = function( pluginPanel ) {
    
    pluginPanel.insert(
        pluginPanel.grid = (new PropertyGrid([
            {
                "name": "fields",
                "label": "Încărcare Câmpuri",
                "expanded": false,
                "items": [
                    {
                        "name": "*",
                        "label": "[ Bifează / Debifează toate câmpurile ]",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "firstName",
                        "label": "Nume",
                        "type": "bool",
                        "value": true
                    },
                    {
                        "name": "lastName",
                        "label": "Prenume",
                        "type": "bool",
                        "value": true
                    },
                    {
                        "name": "sex",
                        "label": "Sex",
                        "type": "bool",
                        "value": true
                    },
                    {
                        "name": "birthDate",
                        "label": "Data naşterii",
                        "type": "bool",
                        "value": true
                    },
                    {
                        "name": "age",
                        "label": "Vârsta",
                        "type": "bool",
                        "value": true
                    },
                    {
                        "name": "studies",
                        "label": "Studii",
                        "type": "bool",
                        "value": true
                    },
                    {
                        "name": "idSerial",
                        "label": "Serie Act Identitate",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "idNumber",
                        "label": "Număr Act Identitate",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "idPersonalCode",
                        "label": "CNP",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "branch",
                        "label": "Judeţ",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "city",
                        "label": "Oraş",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "street",
                        "label": "Stradă",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "number",
                        "label": "Număr",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "numberBlock",
                        "label": "Număr Bloc",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "numberLadder",
                        "label": "Scară",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "numberFloor",
                        "label": "Etaj",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "numberAppartment",
                        "label": "Apartament",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "addressType",
                        "label": "Tip Clădire",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "isCompany",
                        "label": "Tip Adresă",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "latitude",
                        "label": "Latitudine",
                        "type": "bool",
                        "value": true
                    },
                    {
                        "name": "longitude",
                        "label": "Longitudine",
                        "type": "bool",
                        "value": true
                    },
                    {
                        "name": "phoneFixed",
                        "label": "Telefon Fix",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "phoneMobile",
                        "label": "Telefon Mobil",
                        "type": "bool",
                        "value": true
                    },
                    {
                        "name": "email",
                        "label": "Email",
                        "type": "bool",
                        "value": true
                    },
                    {
                        "name": "activeVoter",
                        "label": "Votant Activ",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "party",
                        "label": "Partid",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "school",
                        "label": "Şcoală",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "section",
                        "label": "Secţie Votare",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "misc",
                        "label": "Diverse",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "projects",
                        "label": "Proiecte",
                        "type": "bool",
                        "value": false
                    }
                ]
            },
            {
                "name": "query",
                "label": "Condiţii Căutare",
                "expanded": false,
                "items": [
                    {
                        "name": "firstName",
                        "label": "Nume",
                        "value": "",
                        "type": "varchar"
                    },
                    {
                        "name": "lastName",
                        "label": "Prenume",
                        "value": "",
                        "type": "varchar"
                    },
                    {
                        "name": "sex",
                        "label": "Sex",
                        "value": "",
                        "type": "dropdown",
                        "values": [
                            {
                                "id": "",
                                "name": "- indiferent -"
                            },
                            {
                                "id": "male",
                                "name": "Bărbătesc"
                            },
                            {
                                "id": "female",
                                "name": "Femeiesc"
                            }
                        ]
                    },
                    {
                        "name": "birthDate is",
                        "label": "Dată Naştere =",
                        "type": "date",
                        "value": ""
                    },
                    {
                        "name": "birthDate gt",
                        "label": "Dată Naştere >",
                        "type": "date",
                        "value": ""
                    },
                    {
                        "name": "birthDate lt",
                        "label": "Dată Naştere <",
                        "type": "date",
                        "value": ""
                    },
                    {
                        "name": "age is",
                        "label": "Vârsta =",
                        "type": "int",
                        "value": ''
                    },
                    {
                        "name": "age gt",
                        "label": "Vârsta >",
                        "type": "int",
                        "value": ''
                    },
                    {
                        "name": "age lt",
                        "label": "Vârsta <",
                        "type": "int",
                        "value": ''
                    },
                    {
                        "name": "bornToday",
                        "label": "Născut Astăzi",
                        "type": "bool",
                        "value": false
                    },
                    {
                        "name": "studies",
                        "label": "Studii",
                        "value": "",
                        "type": "dropdown",
                        "values": [
                            {
                                "id": "",
                                "name": "- indiferent -"
                            },
                            {
                                "id": "primare",
                                "name": "Primare"
                            },
                            {
                                "id": "gimnaziale",
                                "name": "Gimnaziale"
                            },
                            {
                                "id": "liceale",
                                "name": "Liceale"
                            },
                            {
                                "id": "postliceale",
                                "name": "Postliceale"
                            },
                            {
                                "id": "superioare",
                                "name": "Superioare"
                            }
                        ]
                    },
                    {
                        "name": "idSerial",
                        "label": "Serie Act Identitate",
                        "type": "varchar",
                        "value": ""
                    },
                    {
                        "name": "idNumber",
                        "label": "Număr Act Identitate",
                        "type": "varchar",
                        "value": ""
                    },
                    {
                        "name": "idPersonalCode",
                        "label": "CNP",
                        "type": "varchar",
                        "value": ""
                    },
                    {
                        "name": "branch",
                        "label": "Judeţ",
                        "type": "varchar",
                        "value": ""
                    },
                    {
                        "name": "city",
                        "label": "Oraş",
                        "type": "varchar",
                        "value": ""
                    },
                    {
                        "name": "street",
                        "label": "Stradă",
                        "type": "varchar",
                        "value": ""
                    },
                    {
                        "name": "number",
                        "label": "Număr",
                        "type": "varchar",
                        "value": ""
                    },
                    {
                        "name": "numberBlock",
                        "label": "Număr Bloc",
                        "type": "varchar",
                        "value": ""
                    },
                    {
                        "name": "numberLadder",
                        "label": "Scară",
                        "type": "varchar",
                        "value": ""
                    },
                    {
                        "name": "numberFloor",
                        "label": "Etaj",
                        "type": "varchar",
                        "value": ""
                    },
                    {
                        "name": "numberAppartment",
                        "label": "Apartament",
                        "type": "varchar",
                        "value": ""
                    },
                    {
                        "name": "addressType",
                        "label": "Tip Locuinţă",
                        "type": "dropdown",
                        "values": [
                            {
                                "id": "",
                                "name": "- oricare -"
                            },
                            {
                                "id": "bloc",
                                "name": "Bloc"
                            },
                            {
                                "id": "casa",
                                "name": "Casă"
                            }
                        ],
                        "value" : ""
                    },
                    {
                        "name": "isCompany",
                        "label": "Tip Locaţie",
                        "type": "dropdown",
                        "value": "",
                        "values": [
                            {
                                "id": "",
                                "name": "- oricare -"
                            },
                            {
                                "id": "individual",
                                "name": "Persoană Fizică"
                            },
                            {
                                "id": "company",
                                "name": "Persoană Juridică"
                            }
                        ]
                    },
                    {
                        "name": "phoneFixed",
                        "label": "Telefon Fix",
                        "type": "varchar",
                        "value": ""
                    },
                    {
                        "name": "phoneMobile",
                        "label": "Telefon Mobil",
                        "type": "varchar",
                        "value": ""
                    },
                    {
                        "name": "email",
                        "label": "Email",
                        "type": "varchar",
                        "value": ""
                    },
                    {
                        "name": "activeVoter",
                        "label": "Votant Activ",
                        "type": "dropdown",
                        "value": "",
                        "values": [
                            {
                                "id": "",
                                "name": "- indiferent -"
                            },
                            {
                                "id": "true",
                                "name": "Da"
                            },
                            {
                                "id": "false",
                                "name": "Nu"
                            }
                        ]
                    },
                    {
                        "name": "party",
                        "label": "Partid",
                        "type": "varchar",
                        "value": ""
                    },
                    {
                        "name": "school",
                        "label": "Şcoală",
                        "type": "varchar",
                        "value": ""
                    },
                    {
                        "name": "section",
                        "label": "Secţie",
                        "type": "varchar",
                        "value": ""
                    }
                ]
            }
        ])).
            setAnchors({
                "width": function(w,h) {
                    return w - 10 + 'px';
                },
                "height": function(w,h) {
                    return h - 40 + 'px';
                }
            }).setAttr(
                "style", "margin: 5px"
            )
    );
    
    pluginPanel.insert(
        (new Button('Caută', function() {
            pluginPanel.doSearch();
        })).setAttr(
            "style", "margin-left: 5px"
        )
    );
    
    pluginPanel.doSearch = function() {
        var data = JSON.stringify( pluginPanel.grid.values );
        var req = [];
        req.addPOST('data', data );
        var rsp = pluginPanel.onedb.$_PLUGIN_JSON_POST(
            '%plugins%/find',
            'find',
            req
        );
        
        new OneDB_FindPanel_ResultSet( rsp, pluginPanel.onedb );
    };
    
    pluginPanel.grid.inputs.fields['*'].addCustomEventListener('change', function() {
        var iChecked = pluginPanel.grid.values.fields['*'];
        
        var props = [
            'firstName',
            'lastName',
            'sex',
            'birthDate',
            "age",
            "studies",
            "idSerial",
            "idNumber",
            "idPersonalCode",
            "branch",
            "city",
            "street",
            "number",
            "numberBlock",
            "numberLadder",
            "numberFloor",
            "numberAppartment",
            "addressType",
            "isCompany",
            "latitude",
            "longitude",
            "phoneFixed",
            "phoneMobile",
            "email",
            "activeVoter",
            "party",
            "colleague",
            "school",
            "section",
            "misc",
            "projects"
        ];
        
        for (var i=0; i<props.length; i++) {
            pluginPanel.grid.values.fields[ props[i] ] = iChecked;
        }
        
    }, false);
}