window['OneDB_FindPanel_ResultSet_cmd_excel'] = function( app ) {

    app.handlers.cmd_excel = function() {
        
        var exportObj = {
            "id": [],
            "fields": []
        };
        
        var sel = app.grid.selection.byRows;
        
        if (sel.length) {
            for (var i=0; i<sel.length; i++) {
                exportObj.id.push(
                    sel[i]._id
                )
            }
        } else {
            for (var i=0; i<app.grid.rows.length; i++) {
                exportObj.id.push(
                    app.grid.rows[i]._id
                )
            }
        }
        
        var sel = app.grid.selection.byColumnsNames;
        
        if (sel.length) {
            for (var i=0; i<sel.length; i++)
                exportObj.fields.push( sel[i] );
        } else {
            for (var i=0; i<app.grid.columns.length; i++) {
                if (app.grid.columns[i].visible)
                    exportObj.fields.push( app.grid.columns[i].name );
            }
        }
        
        if (!exportObj.fields.length) {
            alert("Eroare: Cel puţin 1 coloană trebuie exportată!");
            return;
        }
        
        if (!exportObj.id.length) {
            alert("Eroare: Cel puţin 1 rand trebuie exportat!");
            return;
        }
        
        // console.log( exportObj );
        var req = [];
        req.addPOST('data', JSON.stringify( exportObj ) );
        app.onedb.$_PLUGIN_FORM_POST( '%plugins%/find', 'export-xls', req );
    }
    
}