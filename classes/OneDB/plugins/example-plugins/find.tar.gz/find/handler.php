<?php

    $do = isset( $_POST['do'] ) ? $_POST['do'] : die("What to do?");
    
    function sendSMS( $to, $msg, $from = '' ) {
        return FALSE;
    }
    
    switch ($do) {
    
        case 'suggest-name':
        
            $name = isset($_POST['name']) ? $_POST['name'] : die("Which name?");

            $name = preg_replace('/[^a-z]+/i', ' ', $name);
            $name = preg_replace('/[\s]+/', ' ', $name);
        
            $name = trim( $name ) == '' ? 'Unknown' : ucwords( trim( $name ) );
            
            $_id = isset($_POST['_id']) ? $_POST['_id'] : die("Which _id?");
            $_parent = isset($_POST['_parent']) ? $_POST['_parent'] : die("Which parent?");
        
            $articles = OneDB::get()->articles( array(
                "_parent" => MongoIdentifier( $_parent )
            ) );
        
            $articlesNames = array();
            
            for ($i=0; $i<$articles->length; $i++) {
                $articlesNames[] = $articles->get($i)->name;
            }
        
            $suffix = '';
            $suggest = '';
            
            do {
                $good = TRUE;
                $suggest = $name . ( $suffix == '' ? '' : " - $suffix" );
                foreach ($articlesNames as $article) {
                    if ($article == $suggest) {
                        $good = FALSE;
                        break;
                    }
                }
                $suffix = $suffix == '' ? 1 : $suffix + 1;
            } while (!$good);
        
            echo json_encode( $suggest );
        
            break;
    
        case 'save-person':
            $data = isset( $_POST['data'] ) ? @json_decode( $_POST['data'], TRUE ) : NULL;

            if (!is_array( $data ))
                throw new Exception("Unserializeable person data!");
            
            if (!isset( $data['_parent'] ))
                throw new Exception("Which data[_parent]?");
            
            $thePerson = isset( $data['_id'] ) ?
                OneDB::get()->articles(
                    array(
                        "_id"  => MongoIdentifier( $data['_id'] ),
                        "type" => "Person"
                    )
                )->get(0) :
                OneDB::get()->categories(
                    array(
                        "_id" => MongoIdentifier( $data['_parent'] )
                    )
                )->get(0)
                 ->createArticle('Person');
            
            $keywords = array();
            
            foreach (array_keys( $data ) as $property) {
                if (!in_array( $property, array( "_id", "_parent", "type" ) ) ) {
                    $thePerson->{"$property"} = $data["$property"];
                    
                    if (!empty( $data["$property"] ))
                        $keywords[] = $data["$property"];
                }
            }
            
            $thePerson->keywords = $keywords;
            
            // $thePerson->_autoSave = FALSE;
            // print_r( $thePerson->toArray() );
            
            $thePerson->save();
            
            echo json_encode( "$thePerson->_id" );

            break;
    
        case 'load-person':
            $_id = isset( $_POST['_id'] ) ? $_POST['_id'] : die("Which _id?");
            
            $person = OneDB::get()->articles(
                array(
                    "_id"  => MongoIdentifier( $_id ),
                    "type" => "Person"
                )
            )->get(0);
            
            $out = $person->toArray();
            $out['_id'] = "$out[_id]";
            $out['_parent'] = "$out[_parent]";
            
            echo json_encode( $out );
            
            break;
    
        case 'find':
            $data = isset( $_POST['data'] ) ? @json_decode( $_POST['data'], TRUE ) : die("Which data?");
            
            if (!is_array($data))
                die("Unserializeable data");
            
            require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . "OneDB_MongoQueryBuilder.class.php";

            $queryBuilder = new OneDB_MongoQueryBuilder();
            
            unset( $data['fields']['*'] );
            
            $query = $data['query'];
            
            foreach ( array_keys( $data['query'] ) as $queryField ) {
                
                if (!in_array( $queryField, array( 'age is', 'age gt', 'age lt', 'bornToday' ) ) ) {
                    $queryBuilder->addCondition( $queryField, $data['query']["$queryField"] );
                }
                
            }
            
            $out = array();
            
            foreach (array_keys($data['fields']) as $fieldKey)
                if (!$data['fields'][$fieldKey])
                    unset($data['fields'][$fieldKey]);
            
            $fields = $queryBuilder->fields;
            $fields['type'] = 'Person';
            
            /* Obtain all sections where the user can search */
            $allowedParents = array();
            $security = OneDB::get()->security($_SESSION['UNAME']);
            
            OneDB::get()->categories(
                array(
                    'tags' => 'section'
                )
            )->each( function( $category ) use ( &$allowedParents, &$security )  {
                if ($security->{ "$category->_id" }->canRead())
                    $allowedParents[] = $category->_id;
            });
            
            $fields['_parent'] = array( '$in' => $allowedParents );
            /* End of obtaining all sections where the user can search */
            
            $result = OneDB::get()->db->articles->find(
                $fields
            );
            
            $dataFields = array_keys( $data['fields'] );
            $dataFields[] = '_id';
            
            $todayIs = date('m/d');
            
            while ($result->hasNext()) {
                $arr = $result->getNext();

                $arr['_id'] = "$arr[_id]";
                
                $arr['birthDate'] = isset($arr['birthDate']) ? $arr['birthDate'] : time();
                
                $arr['age'] = floor( abs( time() - $arr['birthDate'] ) / (365*60*60*24) );
                
                $bdate = @date('m/d', $arr['birthDate'] );
                
                $arr['birthDate'] = @date('Y/m/d', $arr['birthDate']);
                
                // include tests that we do outside mongo. Slow !!!
                $inc = TRUE;
                
                foreach ( array( 'age is', 'age lt', 'age gt', 'bornToday' ) as $customField ) {
                    if ( !empty( $data['query'][$customField] ) ) {
                    
                        switch ($customField) {
                            
                            case 'age is':
                                if ($arr['age'] - $data['query']['age is'] != 0) {
                                    $inc = FALSE;
                                    break 2;
                                }
                                break;
                            
                            case 'age lt':
                                if ($data['query']['age lt'] - $arr['age'] <= 0) {
                                    $inc = FALSE;
                                    break 2;
                                }
                                break;
                            case 'age gt':
                                if ($arr['age'] - $data['query']['age gt'] <= 0) {
                                    $inc = FALSE;
                                    break 2;
                                }
                                break;
                            case 'bornToday':
                                if ($bdate != $todayIs) {
                                    $inc = FALSE;
                                    break 2;
                                }
                                break;
                        }
                        
                    }
                }
                
                /* Unset unnecesarry fields */
                foreach (array_keys( $arr ) as $key )
                    if (!in_array( $key, $dataFields ))
                        unset($arr[$key]);
                
                if ($inc) $out[] = $arr;
            }
            
            echo json_encode( array( 'fields'=> array_merge( array('_id'), array_keys( $data['fields'] )), 'data' => $out ) );
            
            break;
            
        case 'export-xls':
        
            $data = isset($_POST['data']) ? @json_decode( $_POST['data'], TRUE ) : die("Which data?");
            
            if (!is_array( $data ) || !isset( $data['id'] ) || !isset( $data['fields'] ) ||
                !is_array( $data['id'] ) || !is_array( $data['fields'] )
            ) die("Bad data!");
        
            ini_set('include_path', ini_get('include_path').'::' . dirname(__FILE__) . '/php_excel/');
            
            require_once 'PHPExcel.php';
            require_once 'PHPExcel/Writer/Excel2007.php';

            $objPHPExcel = new PHPExcel();

            $objPHPExcel->getProperties()->setCreator("OneDB");
            $objPHPExcel->getProperties()->setLastModifiedBy("OneDB");
            $objPHPExcel->getProperties()->setTitle("OneDB_Exported_Document");
            $objPHPExcel->getProperties()->setSubject("Document Subject");
            $objPHPExcel->getProperties()->setDescription("Export of data from OneDB");
            $objPHPExcel->setActiveSheetIndex(0);
            
            $xCols = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z', 'AA', 'AB', 'AC', 'AD', 'AE', 'AF');
            $xNames= array(
                "firstName"     => "Nume",
                "lastName"      => "Prenume",
                "sex"           => "Sex",
                "birthDate"     => "Data Naşterii",
                "age"           => "Vârsta",
                "studies"       => "Studii",
                "idSerial"      => "CI.ID",
                "idNumber"      => "CI.Număr",
                "idPersonalCode"=> "CI.CNP",
                "branch"        => "Judeţ",
                "city"          => "Oraş",
                "street"        => "Stradă",
                "number"        => "Număr",
                "numberBlock"   => "Număr Bloc",
                "numberLadder"  => "Scară",
                "numberFloor"   => "Etaj",
                "numberAppartment" => "Apartament",
                "addressType"   => "Tip Clădire",
                "isCompany"     => "Tip Adresă",
                "latitude"      => "Latitudine",
                "longitude"     => "Longitudine",
                "phoneFixed"    => "Telefon Fix",
                "phoneMobile"   => "Telefon Mobil",
                "email"         => "Email",
                "activeVoter"   => "Votant Activ",
                "party"         => "Partid",
                "colleague"     => "Colegiu",
                "school"        => "Şcoală",
                "section"       => "Secţie",
                "misc"          => "Diverse",
                "projects"      => "Proiecte"
            );
            $xRow = 2;
            $xIndexes = array();

            $sheet = &$objPHPExcel->getActiveSheet();
            
            for ( $i=0; $i<count($data['fields']); $i++) {
                $sheet->SetCellValue( $xCols[$i] . ( 1 ), isset( $xNames[ $data['fields'][$i] ] ) ? $xNames[ $data['fields'][$i] ] : $data['fields'][$i] );
                $xIndexes[ $data['fields'][$i] ] = $i;
            }
            
            for ( $i=0; $i<count($data['id']); $i++)
                $data['id'][$i] = MongoIdentifier( $data['id'][$i] );
            
            $result = OneDB::get()->db->articles->find(
                array(
                    '_id' => array(
                        '$in' => $data['id']
                    )
                )
            );
            
            while ($result->hasNext()) {
                $row = $result->getNext();
                $row['birthDate'] = isset($row['birthDate']) ? $row['birthDate'] : time();
                $row['age'] = floor( abs( time() - $row['birthDate'] ) / (365*60*60*24) );
                $row['birthDate'] = date('Y/m/d', $row['birthDate']);
                
                foreach (array_keys($xIndexes) as $colName)
                    $sheet->setCellValue( $xCols[ $xIndexes[$colName ] ] . $xRow, isset( $row[$colName] ) ? $row[$colName] . '' : '' );
                
                $xRow++;
            }

            $objWriter = new PHPExcel_Writer_Excel2007($objPHPExcel);
            
            $tempNam = tempnam( sys_get_temp_dir(), "XLS-" );
            
            $objWriter->save( $tempNam );
            
            header("Content-type: application/vnd-ms-excel");
            header("Content-disposition: attachment; name=export-" . date('Y_m_d') . ".xlsx");
            
            readfile( $tempNam );
            unlink( $tempNam );
            
            /* echo "Done!";
        
            header("Content-type: text/plain");
            print_r( $_POST ); */
            
            break;
    
        case 'get-mail-templates':
            
            $out = array(
                array(
                    'id' => '',
                    'name' => '- Selectaţi un şablon -'
                )
            );
            
            OneDB::get()->articles( array(
                'tags' => 'email'
            ) )->each( function($article) use (&$out) {
                $out[] = array(
                    'id' => "$article->_id",
                    'name' => "$article->name"
                );
            } );
            
            echo json_encode( $out );
            
            break;

        case 'get-sms-templates':
            
            $out = array(
                array(
                    'id' => '',
                    'name' => '- Selectaţi un şablon -'
                )
            );
            
            OneDB::get()->articles( array(
                'tags' => 'sms'
            ) )->each( function($article) use (&$out) {
                $out[] = array(
                    'id' => "$article->_id",
                    'name' => "$article->name"
                );
            } );
            
            echo json_encode( $out );
            
            break;
        
        case 'fetch-mail-template':
        
            $templateID = isset($_POST['templateID']) ? $_POST['templateID'] : die( "Which templateID?" );
            
            $doc = OneDB::get()->articles(
                array(
                    '_id' => MongoIdentifier( $templateID )
                )
            )->get(0);
            
            echo json_encode( array(
                'name' => $doc->name,
                'data' => $doc->document
            ) );
        
            break;

        case 'fetch-sms-template':
        
            $templateID = isset($_POST['templateID']) ? $_POST['templateID'] : die( "Which templateID?" );
            
            $doc = OneDB::get()->articles(
                array(
                    '_id' => MongoIdentifier( $templateID )
                )
            )->get(0);
            
            echo json_encode( array(
                'data' => $doc->textContent
            ) );
        
            break;
            
        case 'sendmail':

            $body = isset($_POST['body']) ? $_POST['body'] : die("Which body?");
            if (!strlen( trim( $body ) ) )
                die("Nu pot trimite emailul deoarece nu conţine text!");
            
            $from = isset( $_POST['from'] ) ? $_POST['from'] : die("Which from?");
            
            if (!is_email( $from ) )
                die("Aresa de email completată nu este validă!");
            
            $senders = isset( $_POST['senders'] ) ? @json_decode( $_POST['senders'], TRUE ) : die("Which senders?");
            
            if (!is_array( $senders ))
                die("Unserializeable data: senders");
            
            $subject = isset( $_POST['subject'] ) ? $_POST['subject'] : die("Which subject?");
            
            $buff = '';
            $errors = FALSE;
            
            for ($i=0; $i<count( $senders ); $i++) {

                $headers = "MIME-Version: 1.0" . "\r\n";
                $headers .= "Content-type:text/html;charset=utf-8" . "\r\n";

                // More headers
                $headers .= 'From: ' . $from . "\r\n";

                $message = str_replace( '%lastName%', $senders[$i]['lastName'], str_replace( '%firstName%', $senders[$i]['firstName'], $body ) );
                
                $buff .= ( "to: " . $senders[$i]['email'] );
                if ( mail( $senders[$i]['email'], $subject, $message, $headers ) )
                    $buff .= " OK\n";
                else {
                    $buff .= " FAIL!\n";
                    $errors = TRUE;
                }
            }
            
            if (!$errors) {
                echo json_encode('ok');
            } else
                echo "Am întâmpinat erori la trimitere:\n$buff";
            
            break;

        case 'sendsms':

            $body = isset($_POST['body']) ? $_POST['body'] : die("Which body?");
            if (!strlen( trim( $body ) ) )
                die("Nu pot trimite SMS-ul deoarece nu conţine text!");
            
            $from = isset( $_POST['from'] ) ? $_POST['from'] : '';
            
            if (!preg_match('/^([\d]+)?$/', $from))
                die("Numărul de telefon este invalid!");
            
            $senders = isset( $_POST['senders'] ) ? @json_decode( $_POST['senders'], TRUE ) : die("Which senders?");
            
            if (!is_array( $senders ))
                die("Unserializeable data: senders");
            
            $buff = '';
            $errors = FALSE;
            
            for ($i=0; $i<count( $senders ); $i++) {

                $message = str_replace( '%lastName%', $senders[$i]['lastName'], str_replace( '%firstName%', $senders[$i]['firstName'], $body ) );
                
                $buff .= ( "to: " . $senders[$i]['phoneMobile'] );
                if ( sendSMS( $senders[$i]['phoneMobile'], $message, $from ) )
                    $buff .= " OK\n";
                else {
                    $buff .= " FAIL!\n";
                    $errors = TRUE;
                }
            }
            
            if (!$errors) {
                echo json_encode('ok');
            } else
                echo "Am întâmpinat erori la trimitere:\n$buff";
            
            break;
    
        default: {
            throw new Exception("Unknown handler command '$do' in onedb plugin file " . __FILE__ );
        }
    }

?>