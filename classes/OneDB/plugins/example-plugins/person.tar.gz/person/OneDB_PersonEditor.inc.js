window['OneDB_Plugin_Person'] = function( app ) {
    
    app.handlers.cmd_plugin_Person = function( personID ){
        
        var categoryID;
        
        personID = personID || null;
        
        var loadData = {};
        
        (function() {
            if ( personID ) {
                var req = [];
                req.addPOST('_id', personID );
                loadData = app.$_PLUGIN_JSON_POST( '%plugins%/person', 'load-person', req );
                if (loadData === null)
                    throw "Cannot load object: " + personID;
                loadData = loadData || {};
            }
        })();
        
        var currentState = '';
        var currentCity  = '';
        var currentSchool = '';
        var currentSection = '';
        

        (function() {
            categoryID = app.tree.selectedNode.nodeID;
            if (categoryID === null) {
                alert("You cannot create a person here!");
                throw "Cannot create a person in the root node!";
            }
            
            var arr = app.tree.realPath(
                app.tree.selectedNode
            ).trim('/').split('/');
            
            if (arr.length < 4) {
                alert("O persoana se poate crea in interiorul unei sectii de votare (al 4-lea nivel in structura)");
                // alert("You should create a person inside a voting section (at least 5th level tree structure)");
                throw "Cannot create a person here!";
            }
            currentState = arr[0];
            currentCity  = arr[1];
            currentSchool = arr[2];
            currentSection = arr[3];
        })();
        
        var dlg = new Dialog({
            "caption": "Person Editor",
            "width": Math.min( app.width - 50, 1024 ),
            "height": Math.min( app.height - 100, 800 )
        });
        
        Object.defineProperty(
            dlg, 'onedb', {
                "get": function() {
                    return app;
                }
            }
        );
        
        dlg.handlers = {};
        
        dlg.appHandler = function( cmd ) {
            if (typeof dlg.handlers == 'undefined') {
                alert('Command not implemented: ' + cmd);
            } else {
                return dlg.handlers[ cmd ]();
            }
        }
        
        dlg.toolbars = [{
            "name": "Map",
            "items": [
                {
                    "caption": "Copy Map",
                    "id"  : "cmd_copy_map",
                    "handler": dlg.appHandler,
                    "icon" : "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAACUQAAAlEBGgxkpAAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAO/SURBVFiFtZdfaBxFHMc/8+dyl8vlLvG0SW1zNUWbtAml+GIEjRXFV/HBGqUPooKYFymCSEEKIuhbxbc+CPGp+A980KLYgighSq1CsQgpoRBjbFqrjZfbu9292fFh09wludvcXs0Xdm/2NzO/72dnZmf3BF1pj/3DLiC4JVF3bha3tll7JEgtwV6/If107m178eIJmkizb7fk/IVMswbtKAA8gKkpOHUqGdVW8u+14P803yRjbDSAf9Pww5fbB+D7kTcoAfjlw+0DsLYFgMUvYH52ewC2GAEdnsvw2XE49ml0MjeAcrV1cwdwMx1CTPU0btBXFhQo8wIpAuD+9+DJV5vmS7w/y54zV0nnO1oEcFAlvyhlZ3FjVbno66tXSqf1WkQCF05AJg+PHW2Yz6Y1z70yxOh4X2sAobpXj3X6c67Iu898l5fromoZvn0JPj/ZMJPJKCqOiWPeVKkujRVk9aYa7cLPr8HlMzA2CQ8/tVZl05rSdR+AyjIs/Nie+eDhEABrM5sBAJQF5yx8cw6mx+CuYcgV4PLeoNQ5JgFSObj3ifYAAJJKYwPSjQHqQdwZWJiBBRDTBxbUIx8U2retSSqBVCIRDbBBu1JesepWALABzJ2Nb5zMwcADYVlpoWIBDPW7jrviAiDk7U0BgNRCya2b1fT4aDnplb3bc62T1rL1EbhnibmjL5aGvz/ur8Wmzy9TccOdNt+bYGhnhj9+is6T3Q07DoTl1qfAwpvjlPv7vQ63VNuKF5c8VlavjYFDI/GmRbQ6ApOd/Pb8EUalNFS9GO+CLaRkCyPwbMDsyWMMy9XVIkTzl5vvwM356Hw9BUikw7JUQjYF6HJw3znI/OQE+5SqxW3E942QkOiMBhB1y94YazYBpEqYI73MvzFBZv8Q921OIDaG1qRT0LMnGqBeploHUPiH5ZcPsjTxKHfvHWSw6R2IGkBPVtORCK+7Mwrjw+8z0abJLOw8dAsgMEJn+Ks3i5fP4SqJZy2BMVhrCYJg3a8NAoJ0/8ejb331dMMPAmuhWokGkArUau/XD399SftFe2d0l/UaeejcPDDQqE6IrddAvWyjNRAlIT5Ro+Mhr1uElaU4vUNld9Ugq35gYm3FkNEqEbNLhAITBLFGAIzSKlx0ye7waFemagkMXkyAQEm9+tfQgOfEN050gtTgOlWkFKWYAH8rlcgDofm1X+MD7BgJH8VKqQqCuABJrXW4EyW7YeDB+AC35DpVAktR2Ki9dYOEON3XfUfqUmEkV2rfOlRlpZq4seh89B9gW0LuNO95twAAAABJRU5ErkJggg=="
                },
                {
                    "caption": "Paste Map",
                    "id" : "cmd_paste_map",
                    "handler": dlg.appHandler,
                    "icon": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAACUQAAAlEBGgxkpAAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAN/SURBVFiFtZZdbBRVFMd/d2d3O7tl3d1urUu/dilQA0JpTQyGgAqIITUEg4k8kEgQFEiMxsSPmEg0PImJDSb4wIM8CD5BtBJFFNRAjIEmm/hQKBTc2rDWBrot9kNnP2auD0vqdtnOzG63/2Qyd86cO+c3595z7xUsqE7RtjIFgEAwLZlry5lWuPdk4qtIhEtBZK7HhY7SLoeHe5lVHa1ZpJTzcu3cKQkGV5i5OBi/bcxON0cZBoyNpc1cHGTu6vzSPS/xhaEDZM0BAGKfzxeAtAcw/B3Er1aeIJcB3RpA1eD0exWPL3TDJgDA2FfQfbiyAEJKKx/HjFbsA/j5iwoiWMbPAwBw/g0/7YFvjlQkvI0EFAAAODXoeQ26NsGvp+cIYFgSOItaFQkT5+Hsj3DhMahtBX8EvItS4Wiz6059u0OvedAawMYQFAfIB0n3wFAPDEF4gKuJz+gYTrr4ra+Ji+nHOb5gP38tXlscQFovsuYABVoZZkpRoKEuQ0NdnGeJ887ESQ7HOjmR2cub549O+/6w/Gm+l9aToCSAVeH7a7rGl2Ff4Gsix/rYPdI/bX9q6BIxrUW0RWl/ZYVIAoxmSJ66LuP5/QXN/MtLqJbRs8hvn+Ba5yaW5Zsvf9RMx81buIX1eGu6IP5P1WjvndTBF84Zn0CxKphFaya48sz6mcET/UHq/nTbCg6gKpLlPq1ma4SuN1aJR20DiBT6gS24nQUDlr1ba2umF6pKkY6NYdbaA9DhUAv9mzfSet+7tBdcnpIBAGpUWiwBhA7vBrj51p6ZqZ+WdEB1oCyA6ioiYFIFD00y8el6Rp/vZInpl1R/WQCqIFoUIDSOtmsRiddfpq6xPkdpKm+wLACPi6gQQskBSGib5ParqxnftoHmUMjir/Ok+kNoOqhKaQANXgLbF7NMuH0MPeCFgI8pIKvrSCkxpEQaxv93w8jZdT1nkxJj94bVTYde3Nw4+OXHRN2TpREAR/t4zpkal/Ul97ynCx/uOiiEOCA9ftBLB2jyErW9EJnKU14lBD2VAiizFL1KhQBkmRlQKwXgCS0kbQhrxwIpDmrnBCDAAFhY38jv/o6S+yc1+ko6DxSq99ZIbN0jEYQQPPzkFgZuLEVMjoDF7jgw8MfFZCJ+/Nwg3cLGocVUZ97f0bW0MbRdEQ6fla9Epqa0dM/ZS4N73z5xJgHwHyMohJSRAgolAAAAAElFTkSuQmCC"
                }
            ]
        }];
        
        Object.defineProperty(
            dlg, "categoryID", {
                "get": function() {
                    return categoryID;
                }
            }
        );
        
        dlg.grid = dlg.insert(
            (new PropertyGrid([
                {
                    "name": "name",
                    "label": "Nume Obiect (automat)",
                    "type": "Generic",
                    "value": loadData.name || ""
                },
                {
                    "name": "firstName",
                    "label": "Nume",
                    "type": "varchar",
                    "value": loadData.firstName || "",
                    "placeholder": "John"
                },
                {
                    "name": "lastName",
                    "label": "Prenume",
                    "type": "varchar",
                    "value": loadData.lastName || "",
                    "placeholder": "Doe"
                },
                {
                    "name": "sex",
                    "label": "Sex",
                    "type": "dropdown",
                    "values": [
                        {
                            "id": "",
                            "name": "- unspecified -"
                        },
                        {
                            "id": "male",
                            "name": "Bărbătesc"
                        },
                        {
                            "id": "female",
                            "name": "Femeiesc"
                        }
                    ],
                    "value": loadData.sex || ''
                },
                {
                    "name": "birthDate",
                    "label": "Data Naşterii",
                    "type": "date",
                    "value": loadData.birthDate ? ( new Date() ).fromString( loadData.birthDate, '%U' ).toString('%Y/%m/%d') : '',
                    "placeholder": "Date of birth"
                },
                {
                    "name": "age",
                    "label": "Vârstă",
                    "type": "Generic",
                    "value": ""
                },
                {
                    "name": "studies",
                    "label": "Studii",
                    "type": "dropdown",
                    "value": loadData.studies || '',
                    "values": [
                        {
                            "id": "",
                            "name": "- Neprecizat -"
                        },
                        {
                            "id": "primare",
                            "name": "Primare"
                        },
                        {
                            "id": "gimnaziale",
                            "name": "Gimnaziale"
                        },
                        {
                            "id": "liceale",
                            "name": "Liceale"
                        },
                        {
                            "id": "postliceale",
                            "name": "PostLiceale"
                        },
                        {
                            "id": "superioare",
                            "name": "Superioare"
                        }
                    ]
                },
                {
                    "name": "identification",
                    "label": "Date Identificare",
                    "items": [
                        {
                            "name": "idSerial",
                            "label": "Serie CI",
                            "type": "varchar",
                            "value": loadData.idSerial || '',
                            "placeholder": "XX"
                        },
                        {
                            "name": "idNumber",
                            "label": "Număr CI",
                            "type": "varchar",
                            "value": loadData.idNumber || '',
                            "placeholder": "0000000"
                        },
                        {
                            "name": "idPersonalCode",
                            "label": "CNP",
                            "type": "varchar",
                            "value": loadData.idPersonalCode || '',
                            "placeholder": "1111111111111"
                        }
                    ]
                },
                {
                    "name": "address",
                    "label": "Address",
                    "items": [
                        {
                            "name": "branch",
                            "label": "Judeţ",
                            "type": "Generic",
                            "value": loadData.branch || currentState,
                            "placeholder": "Bucharest"
                        },
                        {
                            "name": "city",
                            "label": "Oraş",
                            "type": "Generic",
                            "value": loadData.city || currentCity,
                            "placeholder": "Sector 5"
                        },
                        {
                            "name": "street",
                            "label": "Stradă",
                            "type": "varchar",
                            "value": loadData.street || '',
                            "placeholder": "Victoria Street"
                        },
                        {
                            "name": "number",
                            "label": "Număr",
                            "type": "varchar",
                            "value": loadData.number || '',
                            "placeholder": "92"
                        },
                        {
                            "name": "numberBlock",
                            "label": "Număr Bloc",
                            "type": "varchar",
                            "value": loadData.numberBlock || '',
                            "placeholder": "4F"
                        },
                        {
                            "name": "numberLadder",
                            "label": "Scară",
                            "type": "varchar",
                            "value": loadData.numberLadder || '',
                            "placeholder": "1"
                        },
                        {
                            "name": "numberFloor",
                            "label": "Etaj",
                            "type": "varchar",
                            "value": loadData.numberFloor || '',
                            "placeholder": "0"
                        },
                        {
                            "name": "numberAppartment",
                            "label": "Apartament",
                            "type": "varchar",
                            "value": loadData.numberAppartment || '',
                            "placeholder": "4"
                        },
                        {
                            "name": "addressType",
                            "label": "Tip Clădire",
                            "type": "dropdown",
                            "value": loadData.addressType || "block",
                            "values": [
                                {
                                    "id": "block",
                                    "name": "Bloc"
                                },
                                {
                                    "id": "house",
                                    "name": "Casă"
                                }
                            ]
                        },
                        {
                            "name": "isCompany",
                            "label": "Tip Locaţie",
                            "type": "dropdown",
                            "value": loadData.isCompany || "individual",
                            "values": [
                                {
                                    "id": "individual",
                                    "name": "Persoană Fizică"
                                },
                                {
                                    "id": "company",
                                    "name": "Firmă"
                                }
                            ]
                        },
                        {
                            "name": "latLng",
                            "label": "Latitudine / Longitudine",
                            "type": "Generic",
                            "value": ( loadData.latitude && loadData.longitude ) ? ( loadData.latitude + ' , ' + loadData.longitude ) : ''
                        }
                    ]
                },
                {
                    "name": "contact",
                    "label": "Informaţii Contact",
                    "items": [
                        {
                            "name": "phoneFixed",
                            "label": "Telefon Fix",
                            "type": "varchar",
                            "value": loadData.phoneFixed || ''
                        },
                        {
                            "name": "phoneMobile",
                            "label": "Telefon Mobil",
                            "type": "varchar",
                            "value": loadData.phoneMobile || ''
                        },
                        {
                            "name": "email",
                            "label": "Email",
                            "type": "varchar",
                            "value": loadData.email || ''
                        }
                    ]
                },
                {
                    "name": "political",
                    "label": "Political information",
                    "items": [
                        {
                            "name": "activeVoter",
                            "label": "Votant Activ",
                            "type": "bool",
                            "value": loadData.activeVoter || false
                        },
                        {
                            "name": "party",
                            "label": "Partid",
                            "type": "varchar",
                            "value": loadData.party || ''
                        },
                        {
                            "name": "school",
                            "label": "Şcoală",
                            "type": "Generic",
                            "value": loadData.school || currentSchool
                        },
                        {
                            "name": "section",
                            "label": "Secţie",
                            "type": "Generic",
                            "value": loadData.section || currentSection
                        }
                    ]
                },
                {
                    "name": "other",
                    "label": "Other",
                    "items": [
                        {
                            "name": "misc",
                            "label": "Diverse",
                            "type": "varchar",
                            "value": loadData.misc || ''
                        },
                        {
                            "name": "projects",
                            "label": "Proiecte",
                            "type": "varchar",
                            "value": loadData.projects || ''
                        }
                    ]
                },
                {
                    "name": "database",
                    "label": "!!! Avansat",
                    "expanded": false,
                    "items": [
                        {
                            "name": "_id",
                            "label": "_id",
                            "type": "Generic",
                            "value": personID
                        },
                        {
                            "name": "_parent",
                            "label": "_parent",
                            "type": "Generic",
                            "value": categoryID
                        }
                    ]
                }
            ])).setAnchors({
                "width": function(w,h) {
                    return w - 10 + 'px';
                },
                "height": function(w,h) {
                    return h - 60 + 'px';
                }
            }).setAttr(
                "style", "margin: 5px"
            )
        );
        
        dlg.grid.splitPosition = 180;
        
        OneDB_PersonEditor_cmd_copy_map( dlg );
        OneDB_PersonEditor_cmd_paste_map( dlg );
        
        dlg.insert(
            (new Button('Save', function() {
                dlg.save();
            })).setAttr(
                "style", "position: absolute; left: 5px; bottom: 5px; display: block"
            )
        );
        
        dlg.updatePersonName = function() {
            var firstName = dlg.grid.values.firstName.trim();
            var lastName  = dlg.grid.values.lastName.trim();
            
            var suggestName = ( firstName + ' ' + lastName ).trim();
            suggestName = suggestName || 'Unknown';
            
            var req = [];
            req.addPOST( 'name', suggestName );
            req.addPOST( '_id', dlg.grid.values.database._id );
            req.addPOST( '_parent', dlg.grid.values.database._parent );
            
            var newName = app.$_PLUGIN_JSON_POST( '%plugins%/person', 'suggest-name', req );
            
            dlg.grid.values.name = newName;
            dlg.caption = newName + ' | Person Editor';
            
            return true;
        };
        
        dlg.grid.inputs.firstName.addCustomEventListener('change', function() {
            dlg.updatePersonName();
            return true;
        } );
        
        dlg.grid.inputs.lastName.addCustomEventListener('change', function() {
            dlg.updatePersonName();
            return true;
        } );
        
        dlg.calculateAge = function() {
            var bDate = dlg.grid.values.birthDate;
            var age;
            if (bDate == '') 
                age = '';
            else {
                age = (new Date()).diff(
                    (new Date()).fromString( bDate, '%Y/%m/%d' ), 'years'
                );
            }
            dlg.grid.values.age = age + ( age == '' ? '' : ( age == 1 ? ' year' : ' years' ) );
        }
        
        dlg.grid.inputs.birthDate.addCustomEventListener('change', function() {
            dlg.calculateAge();
        });
        
        dlg.toObject=  function() {
            var out = {};
            
            out.name = dlg.grid.values.name;
            if (!out.name)
                throw "Please fill in firstName and lastName";
            
            out.firstName = dlg.grid.values.firstName;
            if (!out.firstName)
                throw "Please fill in first name!";
            
            out.lastName = dlg.grid.values.lastName;
            if (!out.lastName)
                throw "Please fill in last name!";
            
            out.sex = dlg.grid.values.sex;
            if (!out.sex)
                throw "Please select person sex!";
            
            out.birthDate = dlg.grid.values.birthDate;

            if (!out.birthDate)
                throw "Please select birth date!";
            else
                out.birthDate = parseInt( (new Date()).fromString( out.birthDate + ' 00:00:00', '%Y/%m/%d %H:%i:%S').toString('%U') );
            
            out.studies = dlg.grid.values.studies;
            
            out.idSerial = dlg.grid.values.identification.idSerial;
            out.idNumber = dlg.grid.values.identification.idNumber;
            out.idPersonalCode = dlg.grid.values.identification.idPersonalCode;
            
            out.branch = dlg.grid.values.address.branch;
            out.city = dlg.grid.values.address.city;
            out.street = dlg.grid.values.address.street;
            out.number = dlg.grid.values.address.number;
            out.numberBlock = dlg.grid.values.address.numberBlock;
            out.numberLadder = dlg.grid.values.address.numberLadder;
            out.numberFloor = dlg.grid.values.address.numberFloor;
            out.numberAppartment = dlg.grid.values.address.numberAppartment;
            out.addressType = dlg.grid.values.address.addressType;
            out.isCompany = dlg.grid.values.address.isCompany;
            
            out.phoneFixed = dlg.grid.values.contact.phoneFixed;
            out.phoneMobile = dlg.grid.values.contact.phoneMobile;
            out.email = dlg.grid.values.contact.email;

            if (out.phoneFixed) {
                if (!/^[0-9]+$/.test(out.phoneFixed))
                    throw "Please use only digits for phone numbers!";
            }
            
            if (out.phoneMobile) {
                if (!/^[0-9]+$/.test(out.phoneMobile))
                    throw "Please use only digits for phone numbers!";
            }
            
            if (out.email) {
                if (!/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/.test( out.email ) )
                    throw "Email address seems to be invalid!";
            }
            
            if (!out.phoneFixed && !out.phoneMobile && !out.email)
                throw "Please fill-in at least one field in the person contact!";

            out.activeVoter = dlg.grid.values.political.activeVoter;
            out.party = dlg.grid.values.political.party;
            out.school = dlg.grid.values.political.school;
            out.section = dlg.grid.values.political.section;
            out.misc = dlg.grid.values.other.misc;
            out.projects = dlg.grid.values.other.projects;
            
            if (dlg.grid.values.address.latLng) {
                out.latitude = parseFloat( dlg.grid.values.address.latLng.split(' , ')[0] );
                out.longitude= parseFloat( dlg.grid.values.address.latLng.split(' , ')[1] );
            } else {
                out.latitude = null;
                out.longitude = null;
            }
            
            if (dlg.grid.values.database._id)
                out._id = dlg.grid.values.database._id;
            
            out._parent = dlg.grid.values.database._parent;
            
            return out;
        };
        
        dlg.save = function() {
            try {
                var out = dlg.toObject();
                var req = [];
                req.addPOST('data', JSON.stringify( out ) );
                
                var _id = app.$_PLUGIN_JSON_POST( '%plugins%/person', 'save-person', req );
                // console.log( "Saved: ", _id );
                
                if (_id) {
                    app.appHandler('cmd_refresh');
                    dlg.grid.values.database._id = _id;
                    dlg.close();
                    delete dlg;
                }
                
            } catch (e){
                alert(e);
            }
            
        }
        
        dlg.calculateAge();
        
        window.person = dlg;
        
        return dlg;
    }
    
    app.registerMimeType( /^item\/Person$/, function( obj ) {
        /* console.log( obj ); */
        app.appHandler( 'cmd_plugin_Person', obj.id || obj._id );
    }, 'Person mime opener' );
    
    
    OneDB_RegisterMimeIcon({
        "regex": /^item\/Person$/,
        "icon": "data:image/gif;base64,R0lGODlhMAAwAPf/AJCQkDMzMysrK4yMjIqKip+fn7Kysv9+S7FwPZeXl1FRUZ6env96RTs7PF5eXoaGhggICPnBr/+7YIiIiL+/v5iYmOTk5KioqKysrP+BSfX0wU1NTXx8fHp6epl0O/+VVJKSkri4uMzMzPONTh0dHUlJSaWlpZubm7CwsP/ZGWFhYezs7P+MUXh4eP/5do6Ojv+YVICAgP/UA/+VU8bGxv+eVvmYaP+kWP+5X/+DRMDAwP+MT9TU1MnJyf+sW1ZWVtHR0SMjI3JzeoKCgv+vXKampv/dLP6ZTnV1df/yaXB6fLW1tX5+fmZmZv+gV//dAv+cVv/iO+fn5/+yXf+mWe/x+v6QTsTExP+aVf/tWf/nTP+2Xv+wXGxsbKqqqs/Pz8rKynR0dHV3hOLi4mRkZPHFsba2tmlpaf+qWkVFRYOJjEJCQurq6qKiooSEhODg4JycnNzc3NjY2K6urmpqav/+inJyco2OlllZWVtbW//FZf52Qv/BY//KZm5ubv+8YBAQEP+iWPDx9/++Yf/Oaf+0Xv+TU/+ETJSUlJWVlXBwcO/v7729ve7u7v+iV/+pWsPDw/+0Xbu7u/+nWdvb2/+YU/+tW/Dv7/ikeo6OkLecNu/u7p+goWlqb+fp9f+rV//kJPj4+GhqdP+cVf++YqqiZtPV4e5/V+7p5u/Svv+yYPiyaPacVIpdMKSlqKqytCYXDYWGh4x9RmlPPPn5pv/GaKOlszgpFI6Qm+bFM5iZnnt2Xu3cVvCdTfmPaoSEiu3t7Z6TWP+kU36Bj+7EGP+nXJGRkWxrYv3Fs+7n4pmbm/GMW/2BU6yAQqibVbWNR/T2+rmFcvX4+bepXMLJ1MW0Uda+RNG/Vf/3nveggYKBYJyYcB0RCqCgokwzG/DNvvbjYPPy2tavF+u+DP+ZVfqgYf+bVcl9Q+SwWKGhof+zXfrPHsvNzxgZGvS6kJZpNuzt3O7h3P+tWP/DZOjr8pmdnu/Vxu/bz4iKkO3r6v/0X1Zaa+fo8P+ORgAAAP///yH5BAEAAP8ALAAAAAAwADAAAAj/AP8JHEiwoMGDCBMqVLiIRwUFAYIIaPDgy8KLGIGBAORPQJofPzYEIOEvyAADFjCqJBinHSAHiRYkmsDBzhkVCoIAguCvQcqVF8dACMAhhpsHbpggoaMiZJoGESFAkAOUocQufsJ04NABSZcmDhSUgCogSDsIgKRURUjDHx4HZOj4UaToa9MNTwMIILHT35q1BxWQUPAjjwoyTciQcfBDrN6ILnn6+wl4oMQSGxTgybO5sdgG/iDsPeuvdIXKBEeuWYNZgWsFG0oI8OfNX7vIpf0pQD2QQsfVaTCXCNCu9LtarUJLLh2A98BZuaP7u+WB1CB1OBBwk97AucBVvZp5/xj/DB0hQnxwqONChIgqVudgle7i/d8RLvP09Nk/j88fHFtMQQQak9wQSDEIlGZGfVbII4EEg0Q4yH9bRMKFJWhQcYMTNYwQGhsMfrIFDjg8KAGAARLhQ4GO1AAFFBA4UN8/5QhTyBYjohiJgBgWyCEUVmCyyIzuHDHFFOpEEok6U7DX44Y1mEPOIWXM+E8q/VxIBBdcEmGJDwTe0CIU5FRyQDxWopIDGj60+SUaaDzCIodYwMACM5dY+Y8NR8j5yJ+TFCgmh1LCkEGVet6TAxUa3uDooDXUUOcMLBwAjJ7/bGKDFRs64SmHUU5qyAHfYCpQMhlUAmoNo5hT5wczzP9wQDamDmRPBjO4Sg45MMD6wai+bFLrQGUwsAMWlcQK6w4MnJLPsP80Qskr0eyxxyE7sHDIHgxEo0Q9YICI6RgGIIKCGuxEMEIGOSyDjDRqpDMAEgv00MiMi4gQQwg0QEJALNTwAsoT2tCjDCIFLBBDCxyko5ZzjdAwAAgi9AAGABXoEo4+wXjSRgIYTNBVF4jEkABlgC1yxQJLNHFGF1cYU4EgGtSxDTShMLEEB4r40QEIL8QAwsOAfYEIDWCIQAESNCACAj+0uFCKIF8YY0IFDCcAwAAEcJDIpWtJYQAFV9AgwgSM9HCCMfzUkcQ0giyAASecDGDHAFtPMIEiIQD/RsEFOuhwhQ4UQ1JAJvC4kEU1VbQQAicFxNAE3gNM8MAQTaCMkRQDMCIJBTpAgsQXOhTxiwZJaGGNKQ9ckM4LZ4SRSN5uDKHIBVWJkE4IIXxOQR4G6ICBGNhkEUUutqRjQgJNdFAB0AMgNQQTKoiLUSMPGLCEGbxTMMAZPYQgigtaGLGOGAaccEYMJ8zO9eUxSN7DShacZID23DPixwM0CAFOFCkgxjDa0IQHLCABINgaAeDHs9OoRA7mQgEK7qe9li3gDtcwggw0gYvJHRARxnjB+2LABA60AA8rUIkIToABDKTDABKcoAG6cAdnpEAGu+gEABZwAgQq0Cgx4EoL5vIwBpVcAQ4XKALIWsjEObTgGE8Yxz6MUYAKJACEIiRAGNwQxA60wAE8UAkFFnCBChjDCxdIoxqHJw5Z4KMAPUxEArlGgDMMQYgtUMH8MCKCIbSvdSYoQhFMQEgTuEIIQuhGHOdIAL01gQOQbEETuhBGlVDCC11pwyBN0IZ0dLINSADBIgEgQss9QAVaacIPHvCGqiziDTpYQAuGMIAKcCIdt+xCFa8IghBybQgdwAMe/FCEOPCmERYAghkS8DI7eAWSJkRCXZrAmezx4F56WoEFKMEDMEDCc4ygAA2+IAcLgA1amAoIADs="
    });
    
    
};