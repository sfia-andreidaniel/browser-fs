window['OneDB_PersonEditor_cmd_paste_map'] = function( app ) {
    
    app.handlers.cmd_paste_map = function() {
        
        if (typeof app.onedb.plugins['%plugins%/google_maps'] == 'undefined') {
            alert("OneDB plugin called Google Maps was not loaded. Please load it first!");
        }
        
        var googleMaps_Sheet = app.onedb.plugins['%plugins%/google_maps']['plugin.json'].plugin.sheetInstance;
        //console.log( googleMaps_Sheet );
        //window.gm = googleMaps_Sheet;
        
        if (app.grid.values.address.latLng) {
            var latLng = app.grid.values.address.latLng.split(' , ');
            googleMaps_Sheet.latitude = latLng[0];
            googleMaps_Sheet.longitude = latLng[1];
            googleMaps_Sheet.centerToMarker();
        } else {
            googleMaps_Sheet.address = (app.grid.values.address.branch + ' ' +
                                       app.grid.values.address.city + ' ' +
                                       app.grid.values.address.street + ' ' +
                                       app.grid.values.address.number).trim();
        }
    
    }
    
};