<?php

    $__OneDB_Default_Person__ = array(
        'firstName'       => '', // x nume
        'lastName'        => '', // x prenume
        'idSerial'        => '', // x bi/ci serie
        'idNumber'        => '', // x bi/ci nr
        'idPersonalCode'  => '', // x cnp
        'sex'             => '', // x sex
        'birthDate'       => 0,  // x data nasterii
        'studies'         => '', // x studii
        'branch'          => '', // x judetul
        'city'            => '', // x orasul
        'street'          => '', // x strada
        'number'          => '', // x numar
        'numberBlock'     => '', // x numar bloc
        'numberLadder'    => '', // x numar scara
        'numberFloor'     => '', // x numar etaj
        'numberAppartment'=> '', // x numar apartament
        'addressType'     => '', // x locuinta ("bloc", "casa", "firma")
        'isCompany'       => '', // x (individual, company)
        'phoneFixed'      => '', // x telefon fix
        'phoneMobile'     => '', // x telefon mobil
        'email'           => '', // x email
        'activeVoter'     => TRUE, // x votant activ
        'party'           => '', // x partid simpatizant
        // 'colleague'       => '', // x colegiul
        'school'          => '', // x scoala
        'section'         => '', // x sectia
        'misc'            => '', // x diverse
        'projects'        => '', // x proiecte
        'latitude'        => NULL, // x geo latitude
        'longitude'       => NULL  // x geo longitude
    );

    require_once dirname(__FILE__) . DIRECTORY_SEPARATOR . 'OneDB_Article_plugin_Person.class.php';

    OneDB_RegisterBackendObject( array(
        'backendName'       => 'Person',
        'docType'           => 'Person',
        'icon'              => 'data:image/gif;base64,R0lGODlhEAAQANUAACAKIUlAfJqYpXd5m05i+Ftu/Uhg8Txa5EFc6mR9/StO1lBx6l5+9CBHyzNa13GR/hJAvhRBwCpVyTlfxuDh5Ag6tUVqzC5Bb2yJzkhyyJyuzLPH4Mna5jc3NpWVlFFQTl1cWrGwrnh1cf2YNEdGRfWNL+qELNp0J9NtJJBLGj0jE71XHcJcHzozL31xaxUTEiEfHqpEFzUVB7RwUxUOC4QlDnIaCeDU0tHR0cLCwoaGhnd3dyQkJBUVFQYGBv///yH5BAEAAD8ALAAAAAAQABAAAAaWwJ9wSCwaKbrdDmckelo7j6jlaf5yMJAo5CG9ck0S6dNp2WIplxEHI3VSpZF8ZgzBWjBTaW+iF0M9PCooJ4UofkQUPT00KyssKzGITi8+MjUxMTU3VjgXADY1NgEYFE0YCxIDAhoWDBZGGggJDxIbHBYJBxtFEwQFCQwZHA4Fu0UQB78FDhkGBhIcRRgQDQrXFRYY0kJBADs=',
        'defaultNamePrefix' => 'Person %d%t'
    ) );

?>