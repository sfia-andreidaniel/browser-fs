window['OneDB_PersonEditor_cmd_copy_map'] = function( app ) {
    
    app.handlers.cmd_copy_map = function() {
        
        if (typeof app.onedb.plugins['%plugins%/google_maps'] == 'undefined') {
            alert("OneDB plugin called Google Maps was not loaded. Please load it first!");
        }
        
        var googleMaps_Sheet = app.onedb.plugins['%plugins%/google_maps']['plugin.json'].plugin.sheetInstance;
        //console.log( googleMaps_Sheet );
        //window.gm = googleMaps_Sheet;
        app.grid.values.address.latLng = googleMaps_Sheet.latitude + ' , ' + googleMaps_Sheet.longitude;
    }
    
};