<?php

    $do = isset( $_POST['do'] ) ? $_POST['do'] : die("What to do?");
    
    switch ($do) {
    
        case 'suggest-name':
        
            $name = isset($_POST['name']) ? $_POST['name'] : die("Which name?");

            $name = preg_replace('/[^a-z]+/i', ' ', $name);
            $name = preg_replace('/[\s]+/', ' ', $name);
        
            $name = trim( $name ) == '' ? 'Unknown' : ucwords( trim( $name ) );
            
            $_id = isset($_POST['_id']) ? $_POST['_id'] : die("Which _id?");
            $_parent = isset($_POST['_parent']) ? $_POST['_parent'] : die("Which parent?");
        
            $articles = OneDB::get()->articles( array(
                "_parent" => MongoIdentifier( $_parent )
            ) );
        
            $articlesNames = array();
            
            for ($i=0; $i<$articles->length; $i++) {
                $articlesNames[] = $articles->get($i)->name;
            }
        
            $suffix = '';
            $suggest = '';
            
            do {
                $good = TRUE;
                $suggest = $name . ( $suffix == '' ? '' : " - $suffix" );
                foreach ($articlesNames as $article) {
                    if ($article == $suggest) {
                        $good = FALSE;
                        break;
                    }
                }
                $suffix = $suffix == '' ? 1 : $suffix + 1;
            } while (!$good);
        
            echo json_encode( $suggest );
        
            break;
    
        case 'save-person':
            $data = isset( $_POST['data'] ) ? @json_decode( $_POST['data'], TRUE ) : NULL;

            if (!is_array( $data ))
                throw new Exception("Unserializeable person data!");
            
            if (!isset( $data['_parent'] ))
                throw new Exception("Which data[_parent]?");
            
            $thePerson = isset( $data['_id'] ) ?
                OneDB::get()->articles(
                    array(
                        "_id"  => MongoIdentifier( $data['_id'] ),
                        "type" => "Person"
                    )
                )->get(0) :
                OneDB::get()->categories(
                    array(
                        "_id" => MongoIdentifier( $data['_parent'] )
                    )
                )->get(0)
                 ->createArticle('Person');
            
            $keywords = array();
            
            foreach (array_keys( $data ) as $property) {
                if (!in_array( $property, array( "_id", "_parent", "type" ) ) ) {
                    $thePerson->{"$property"} = $data["$property"];
                    
                    if (!empty( $data["$property"] ))
                        $keywords[] = $data["$property"];
                }
            }
            
            $thePerson->keywords = $keywords;
            
            // $thePerson->_autoSave = FALSE;
            // print_r( $thePerson->toArray() );
            
            $thePerson->save();
            
            echo json_encode( "$thePerson->_id" );

            break;
    
        case 'load-person':
            $_id = isset( $_POST['_id'] ) ? $_POST['_id'] : die("Which _id?");
            
            $person = OneDB::get()->articles(
                array(
                    "_id"  => MongoIdentifier( $_id ),
                    "type" => "Person"
                )
            )->get(0);
            
            $out = $person->toArray();
            $out['_id'] = "$out[_id]";
            $out['_parent'] = "$out[_parent]";
            
            echo json_encode( $out );
            
            break;
    
        default:
            throw new Exception("Unknown handler command '$do' in onedb plugin file " . __FILE__ );
    }

?>