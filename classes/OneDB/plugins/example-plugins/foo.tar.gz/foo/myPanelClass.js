window.myPanelClass = function( tabSheet ) {
    
    tabSheet.insert(
        $('p').setHTML('This is a foo').setAttr('style', 'margin: 10px')
    );
    
    
}