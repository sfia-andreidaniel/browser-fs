window.OneDB_FooPlugin = function() {
    console.log( "plugin initialized" );
}