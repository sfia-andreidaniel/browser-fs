window.OneDB_GoogleMapsPlugin = function() {
    console.log( "plugin initialized" );
    console.log( "plugin arguments: ", arguments );
}