window.onedbGoogleMaps_Panel = function( tabSheet ) {
    
    var mapOptions;
    var map;    // the google.maps.map
    var cluster; // the marker clusterer
    var marker;
    var latLng;
    var geocoder;
    
    tabSheet.insert( new DOMLabel( 'Latitude / Longitude:', {
        'x': 10, 'y': 10
    } ) );
    
    var lat, lng;
    
    tabSheet.insert(
        (lat = new Spinner({
            "value": 44.43148,
            "minValue": -90,
            "maxValue": 90,
            "step": 0.0001
        })).setAttr(
            "style", "width: 150px; left: 150px; top: 5px; position: absolute; display: block;"
        )
    );

    tabSheet.insert(
        (lng = new Spinner({
            "value": 26.13442,
            "minValue": -180,
            "maxValue": 180,
            "step": 0.0001
        })).setAttr(
            "style", "width: 150px; left: 310px; top: 5px; position: absolute; display: block;"
        )
    );
    
    tabSheet.insert(
        ( new Button('Center', function() {
            tabSheet.centerToMarker();
        }) ).setAttr(
            'style', 'position: absolute; top: 5px; left: 470px; width: 50px'
        )
    );
    
    tabSheet.insert(
        ( tabSheet.btnFullScreen = new Button('Full Screen', function() {
            tabSheet.fullScreen = !tabSheet.fullScreen;
        }) ).setAttr(
            'style', 'position: absolute; top: 5px; left: 530px; width: 90px'
        )
    );
    
    tabSheet.insert(
        ( tabSheet.btnPopOut = new Button('PopOut', function() {
            tabSheet.dettached = !tabSheet.dettached;
        }) ).setAttr(
            'style', 'position: absolute; top: 5px; left: 630px; width: 80px'
        )
    );
    
    tabSheet.insert(
        ( new Button('Save Map', function() {
            tabSheet.saveMap();
        }) ).setAttr(
            'style', 'position: absolute; top: 5px; left: 720px; width: 80px;'
        )
    );
    
    lat.addCustomEventListener( 'change', function() {
        marker.setPosition( new google.maps.LatLng( tabSheet.latitude, tabSheet.longitude ) );
        tabSheet.centerToMarker();
    });
    
    lng.addCustomEventListener( 'change', function() {
        marker.setPosition( new google.maps.LatLng( tabSheet.latitude, tabSheet.longitude ) );
        tabSheet.centerToMarker();
    });
    
    Object.defineProperty(
        tabSheet, 'latitude', {
            "get": function() {
                return lat.value;
            },
            "set": function( v ) {
                lat.value = v;
                marker.setPosition( new google.maps.LatLng( tabSheet.latitude, tabSheet.longitude ) );
            }
        }
    );

    Object.defineProperty(
        tabSheet, 'longitude', {
            "get": function() {
                return lng.value;
            },
            "set": function( v ) {
                lng.value = v;
                marker.setPosition( new google.maps.LatLng( tabSheet.latitude, tabSheet.longitude ) );
            }
        }
    );
    
    Object.defineProperty(
        tabSheet, 'address', {
            "get": function() {
                return null;
            },
            "set": function(str) {
                geocoder.geocode( { "address": str }, function( results, status ) {
                    if ( status == google.maps.GeocoderStatus.OK ) {
                        //console.log( "Location: ", results[0].geometry.location );
                        var loc = results[0].geometry.location;
                        tabSheet.latitude = loc['$a'];
                        tabSheet.longitude= loc['ab'];
                        tabSheet.centerToMarker();
                    } else {
                        alert("Cannot paste address:\n" + status );
                    }
                } );
            }
        }
    );
    
    tabSheet.insert(
        (tabSheet.googleMapsContainer = $('div')).
            setAnchors({
                "width": function(w,h) {
                    return w - 14 + 'px';
                },
                "height": function(w,h) {
                    return h - 50 + 'px';
                },
                "dummy": function(w, h) {
                    try {
                        google.maps.event.trigger(map, 'resize')
                    } catch (silent) {}
                }
            }).setAttr(
                "style", "display: block; position: absolute; left: 5px; top: 40px; border: 1px solid green"
            )
    );
    
    /* Instantiate the callback function */
    var readyCallback = 'gmaps_callback_' + getUID();
    
    tabSheet.centerToMarker = function() {
        var position = marker.getPosition();
        map.panTo( position );
        
        tabSheet.latitude = position.lat();
        tabSheet.longitude= position.lng();
    }
    
    window[ readyCallback ] = function() {
    
        latLng = new google.maps.LatLng( 44.43148, 26.13442 );
    
        mapOptions = {
            "zoom": 17,
            "mapTypeId": 'roadmap',
            "center": latLng
        };
        
        geocoder = new google.maps.Geocoder();
        
        map = new google.maps.Map( tabSheet.googleMapsContainer, mapOptions );
        
        marker = new google.maps.Marker({
            "map": map,
            "draggable": true,
            "animation": google.maps.Animation.DROP,
            "position": latLng
        });
        
        tabSheet.centerToMarker();
        
        google.maps.event.addListener( marker, 'mouseup', function() {
            tabSheet.centerToMarker();
        } );
        
        var initCluster = function() {
            if (typeof window.MarkerClusterer == 'undefined') {
                console.log( 'Waiting 1 sec for cluster to load...');
                setTimeout( initCluster, 1000 );
            }
            else { 
                console.log( "cluster was inited" );
                cluster = new MarkerClusterer( map );
            }
        };
        
        initCluster();
        
        delete window[ readyCallback ];
    };
    
    (function() {
        var script = document.createElement( 'script' );
        script.type = 'text/javascript';
        script.src = 'http://maps.googleapis.com/maps/api/js?' + /* key=YOUR_API_KEY&  + */ 'sensor=true&callback=' + readyCallback;
        document.body.appendChild( script );
        
        /* add google maps marker cluster */
        var script1 = document.createElement('script');
        script1.type = 'text/javascript';
        script1.src = 'contrib/google.markercluster.v3/markerclusterer.js';
        document.body.appendChild( script1 );
    })();
    
    var transferContent = function( domObjectSrc, domObjectDst ) {

        var nodes = [];
        var cursor = domObjectSrc.firstChild;

        while (cursor) {
            nodes.push( cursor );
            cursor = cursor.nextSibling;
        }
        
        for (var i=0; i<nodes.length; i++) {
            domObjectDst.appendChild( nodes[i] );
        }
    };
    
    (function () { 
        var dettached = false;
        var dtWindow = false;
        var bRestoreInside = false;
        
        Object.defineProperty( tabSheet, 'dettached', {
            "get": function() {
                return dettached;
            },
            "set": function( bValue ) {
                bValue = !!bValue;

                if (bValue == dettached) return;
                
                if (tabSheet.fullScreen && bValue) {
                    alert("Cannot PopOut plugin while in full screen!");
                    return;
                }
                
                switch (bValue) {
                    case true:
                        dtWindow = new Dialog({
                            "width": getMaxX() - 100,
                            "height": getMaxY() - 100,
                            "caption": "Google Maps",
                            "closeable": false
                        });
                        
                        transferContent( tabSheet.firstChild, dtWindow.body );
                        
                        try {
                            google.maps.event.trigger( map, 'resize' );
                        } catch (e) {}
                        dtWindow.paint();
                        tabSheet.btnPopOut.innerHTML = 'PopIn';
                        tabSheet.btnFullScreen.disabled = true;
                        
                        tabSheet.insert(
                            bRestoreInside = (new Button('Pop In', function() {
                                tabSheet.dettached = false;
                            })).setAnchors({
                                "left": function( w, h ) {
                                    return ( w - 50 ) / 2 + 'px';
                                },
                                "top": function( w, h ) {
                                    return ( h - 20 ) / 2 + 'px';
                                }
                            }).setAttr(
                                "style", "position: absolute; left: 1px; top: 1px; display: block; width: 100px"
                            )
                        );
                        
                        break;
                    case false:
                        bRestoreInside.parentNode.removeChild( bRestoreInside );
                        bRestoreInside = false;
                        
                        transferContent( dtWindow.body, tabSheet.firstChild );
                        getOwnerWindow( tabSheet ).paint();
                        dtWindow.closeable = true;
                        dtWindow.close();
                        dtWindow = false;
                        tabSheet.btnPopOut.innerHTML = 'PopOut';
                        tabSheet.btnFullScreen.disabled = false;
                        break;
                }
                
                try {
                    tabSheet.centerToMarker();
                } catch (e){}
                
                dettached = bValue;
            }
        });
        
    })();
    
    (function() {
        var fullScreen = false;
        var fsOverlay = false;
        
        var windowResizeFunc = null;
        
        Object.defineProperty( tabSheet, 'fullScreen', {
            'get': function() {
                return fullScreen;
            },
            'set': function ( bValue ) {

                bValue = !!bValue;

                if (bValue == fullScreen) return;

                switch (bValue) {
                    case true:
                        fsOverlay = $('div');
                        fsOverlay.style.display = 'block';
                        fsOverlay.style.position = 'absolute';
                        fsOverlay.style.backgroundColor = '#ddd';
                        fsOverlay.style.left = fsOverlay.style.right = fsOverlay.style.top = fsOverlay.style.bottom = '0px';
                        fsOverlay.style.zIndex = 9000000;
                        document.body.appendChild( fsOverlay );
                        transferContent( tabSheet, fsOverlay );
                        fsOverlay.onDOMresize( getMaxX(), getMaxY() );
                        try {
                            google.maps.event.trigger(map, 'resize');
                        } catch (silent) { }
                        windowResizeFunc = function() {
                            fsOverlay.onDOMresize( getMaxX(), getMaxY() );
                        };
                        window.addEventListener( 'resize', windowResizeFunc, false );
                        tabSheet.btnPopOut.disabled = true;
                        tabSheet.btnFullScreen.innerHTML = 'Restore';
                        break;
                    case false:
                        window.removeEventListener( 'resize', windowResizeFunc, false );
                        windowResizeFunc = false;
                        transferContent( fsOverlay, tabSheet );
                        document.body.removeChild( fsOverlay );
                        getOwnerWindow( tabSheet ).paint();
                        fsOverlay = false;
                        tabSheet.btnPopOut.disabled = false;
                        tabSheet.btnFullScreen.innerHTML = 'Full Screen';
                        break;
                }
                
                try {
                    tabSheet.centerToMarker();
                } catch (e) {}
                
                fullScreen = bValue;
            }
        } );
    })();

    tabSheet.saveMap = function() {
        var canvas = $('canvas');
        canvas.setAttribute('width', tabSheet.googleMapsContainer.offsetWidth);
        canvas.setAttribute('height', tabSheet.googleMapsContainer.offsetHeight);
        var context = canvas.getContext('2d');
        var imgs = tabSheet.googleMapsContainer.getElementsByTagName('img');
        
        //console.log ( imgs );
        
        canvas.trySave = function() {
            canvas.imgs--;
            if (canvas.imgs == 0) {
                try {
                    if (canvas.renderLast) {
                        for (var i=0; i<canvas.renderLast.length; i++) {
                            context.drawImage(canvas.renderLast[i].img, canvas.renderLast[i].x, canvas.renderLast[i].y);
                            tabSheet.googleMapsContainer.removeChild(canvas.renderLast[i].img);
                        }
                        canvas.renderLast = [];
                    }
                    
                    Canvas2Image.saveAsJPEG( canvas );
                    
                } catch (ex) {
                    alert('Could not save map: ' + ex);
                }
            }
        };
        
        canvas.addImageFromProxy = function(remoteImg, x, y) {
            var translateX = 0;
            var translateY = 0;
            var renderLast = false;
            
            if (remoteImg.offsetWidth == 256 && remoteImg.offsetHeight == 256) {
                var dragZone = remoteImg.parentNode.parentNode.parentNode.parentNode;
            } else {
                if (!/marker_sprite.png$/.test(remoteImg.src)) {
                    return;
                } else {
                    var dragZone = remoteImg.parentNode.parentNode.parentNode;
                    renderLast = true;
                }
            }
            
            if (dragZone.style.webkitTransform || dragZone.style.transform ) {
                
                var transform = dragZone.style.webkitTransform || dragZone.style.transform;

                var match;
                
                switch (true) {
                    case ( match = /translate\(([-])?([0-9]+)px, ([-])?([0-9]+)px/.exec(transform) ) !== null:
                        translateX = parseInt(match[2]) * (match[1] ? -1 : 1);
                        translateY = parseInt(match[4]) * (match[3] ? -1 : 1);
                        x = x + translateX;
                        y = y + translateY;
                        break;
                    case ( match = /^matrix\([\s\d\-]+,[\s\d\-]+,[\s\d\-]+,[\s\d\-]+,([\s\d\-]+),([\s\d\-]+)\)$/.exec( transform ) ) !== null:
                        translateX = parseInt( match[1].trim() );
                        translateY = parseInt( match[2].trim() );
                        x = x + translateX;
                        y = y + translateY;
                        break;
                }
                
            } else {
                if (dragZone.style.left) {
                    translateX = parseInt(dragZone.style.left);
                    x = x + translateX;
                } else {
                    translateX = parseInt( dragZone.offsetLeft);
                    x = x +  translateX;
                }
                
                if (dragZone.style.top) {
                    translateY = parseInt(dragZone.style.top);
                    y = y + translateY;
                } else {
                    translateX = parseInt( dragZone.offsetTop );
                    y = y + translateY;
                }
            }
            
            
            if ((x < remoteImg.offsetWidth) || (x > tabSheet.googleMapsContainer.offsetWidth) ||
                (y < remoteImg.offsetHeight) || (y > tabSheet.googleMapsContainer.offsetHeight)) {
                console.log( 'image skipped: ', x, y, ': outside overlay!' );
            }
            
            var img = document.createElement('img');
            img.src = 'sessions/0/lib/gmaps_browser/proxy.php?url='+escape(remoteImg.src);
            img.style.width = '1px';
            img.style.height = '1px';
            
            tabSheet.googleMapsContainer.appendChild(img);
            
            canvas.imgs = canvas.imgs || 0;
            canvas.imgs++;
            
            img.onerror = function() {
                tabSheet.googleMapsContainer.removeChild( img );
                console.log( 'Fail: ', remoteImg.src );
                canvas.trySave();
            };
            
            img.onload = function() {
                img.style.width = remoteImg.offsetWidth+'px';
                img.style.height= remoteImg.offsetHeight+'px';
                
                if (renderLast == true) {
                    canvas.renderLast = canvas.renderLast || [];
                    canvas.renderLast.push({ 'img': img, 'x': x, 'y': y});
                    renderLast = false;
                } else {
                    context.drawImage(img, x, y);
                    tabSheet.googleMapsContainer.removeChild( img );
                }
                canvas.trySave();
            }
        }
        
        console.log( window.cl = cluster );
        return;
        
        for (var i = 0; i<imgs.length; i++) {
            if ( imgs[i].offsetWidth == 256 &&
                 imgs[i].offsetHeight == 256
            ) {
                canvas.addImageFromProxy(imgs[i], imgs[i].parentNode.offsetLeft, imgs[i].parentNode.offsetTop);
            }
        }
        
        if (document.querySelectorAll) {
            var gmnoprints = tabSheet.googleMapsContainer.querySelectorAll('div.gmnoprint > img');
            for (var i=0; i<gmnoprints.length; i++) {
                canvas.addImageFromProxy(gmnoprints[i], gmnoprints[i].parentNode.offsetLeft, gmnoprints[i].parentNode.offsetTop);
            }
        }
        
    };
    
    ( function() {
        Object.defineProperty(
            tabSheet, "cluster", {
                "get": function() {
                    return cluster.getMarkers();
                },
                "set": function( arr ) {
                    if (!( arr instanceof Array ))
                        throw "plugin.markers: parameter should be an array!";
                    
                    cluster.clearMarkers();
                    
                    var ar = [];
                    
                    if (arr.length) {
                        for ( var i=0; i<arr.length; i++) {
                            var latLng = new google.maps.LatLng(
                                arr[i].latitude,
                                arr[i].longitude
                            );
                            var m = new google.maps.Marker({
                                "position": latLng,
                                "icon"    : "img/user-24x24.png?addsave=true"
                            });
                            ar.push( m );
                        }
                        cluster.addMarkers( ar );
                    }
                }
            }
        );
    })();
    
    window.gm = tabSheet;
    
    return tabSheet;
}

//@ sourceURL=onedbGoogleMaps_Panel.backend.inc.js