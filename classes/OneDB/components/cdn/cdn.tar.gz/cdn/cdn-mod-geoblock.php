<?php
    function OneDB_RemoteAddr() {
        foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED',
                       'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key) {
           if (array_key_exists($key, $_SERVER) === true) {
               foreach (explode(',', $_SERVER[$key]) as $ip) {
                   if (filter_var($ip, FILTER_VALIDATE_IP) !== false) {
                       return $ip;
                   }
               }
           }
       }
   }
   
    function OneDB_Ip2Country( $IP ) {
        $buffer = @file_get_contents( "http://82.76.249.42/api/ds_entitlement.php?ip=" . $IP . "&from=cacher" );
        return strlen( "$buffer" ) == 2 ? strtolower( $buffer ) : '-';
    }

?>