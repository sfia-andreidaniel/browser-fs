#!/usr/bin/php
<?php

    chdir( dirname(__FILE__) );

    require_once "open_db.php";
    
    $age = isset($argv[1]) ? (int)$argv[1] : 86400;
    
    echo "cdn-purge v1.0\nstart-date: " . @date('l jS \of F Y h:i:s A') . "\npurgin' older files than $age seconds\n\n";
    
    $sql = "select unix_timestamp(NOW()) - unix_timestamp(date) AS age, file FROM cdn";
    $result = mysql_query( $sql ) or die("mysql_error(): " . mysql_error() . "\n");
    
    while ($row = mysql_fetch_array( $result, MYSQL_ASSOC )) {
        
        echo str_pad( $row['file'], 96, ' ', STR_PAD_RIGHT), ': ';
        
        if ($age - (int)$row['age'] > 0) {
            echo "FRESH ($row[age] secs)\n";
        } else {
            if (@unlink($row['file'])) {
                if (mysql_query("DELETE FROM cdn WHERE file='" . mysql_escape_string( $row['file'] ) . "' LIMIT 1"))
                    echo "OLD\n";
                else
                    echo "OLD (Kept in db)\n";
            } else
                echo "Could not delete file!\n";
        }
    }

?>