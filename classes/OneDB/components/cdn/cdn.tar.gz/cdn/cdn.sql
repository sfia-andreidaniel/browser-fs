DROP TABLE IF EXISTS `cdn`;

CREATE TABLE `cdn` (
  `url` varchar(256) NOT NULL DEFAULT '',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `file` varchar(256) NOT NULL DEFAULT '',
  `geo_blocking` char(255) DEFAULT NULL,
  PRIMARY KEY (`url`),
  KEY `file` (`file`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
