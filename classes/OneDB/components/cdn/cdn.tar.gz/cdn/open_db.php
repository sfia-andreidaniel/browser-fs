<?php

    $conn = mysql_connect('127.0.0.1', 'cdn', 'cdn') or die("Could not connect to mysql server: " . mysql_error());
    $db   = mysql_select_db( 'cdn', $conn ) or die("Could not select database cdn: " . mysql_error() );

?>