<?php


    define('QT_FASTSTART', '/usr/local/bin/qtfaststart' );
    define('FLVTOOL2',     '/usr/bin/flvtool2');

    define('CDN_MASTER', 'http://www2.digisport.ro');
    define('CDN_GEOBLOCK_SECRET_KEY', 'GEOBLOCK:');
    
    /* Deny serving the following mime http types (specify them as regular expression) */
    $CDN_SKIP_CONTENT_TYPES = array(
        '/^text\/html$/i'
    );
    
    $SHUTDOWN_CLOSE_FILES = array();
    
    ignore_user_abort( TRUE );
    set_time_limit( 0 );
    
    function registerShutdownCloseFile( $fileHandle ) {
        global $SHUTDOWN_CLOSE_FILES;
        $SHUTDOWN_CLOSE_FILES[] = $fileHandle;
    }
    
    function shutdownCloseFiles() {
        global $SHUTDOWN_CLOSE_FILES;
        for ($i=0; $i<count($SHUTDOWN_CLOSE_FILES); $i++) {
            @fclose( $SHUTDOWN_CLOSE_FILES[$i] );
        }
    }
    
    register_shutdown_function('shutdownCloseFiles');
    
    function error( $errorCode, $errorText, $additionalText = '' ) {
        header("HTTP/1.1 $errorCode $errorText");
        header('Content-Type: text/plain');
        die( $errorText . "\n" . $additionalText );
    }
    
    function stripQueryParameters( $url ) {
        $parts = explode('?', $url);

        if (count( $parts ) > 1) {

            $partss = implode( '?', array_slice( $parts, 1 ) );
            
            if (strpos( $partss, 'NO-LOOP=1' ) !== FALSE) {
                header('HTTP/1.1 404 Not Found');
                header('Content-Type: text/plain');
                die('Content not found (X-CDN-Loop On)');
            }
        }

        return reset( $parts );
    }

    function get_ip_address() {
        foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                    foreach (explode(',', $_SERVER[$key]) as $ip) {
                        if (filter_var($ip, FILTER_VALIDATE_IP) !== false) {
                        return $ip;
                    }
                }
            }
        }
    }

    function serveGeoBlockedUrl( $remoteURL, $requestURI ) {
        $sql = "SELECT * FROM cdn WHERE url='$remoteURL' LIMIT 1";
        $result = mysql_query( $sql );
        
        if (!$result)
            return FALSE;
        
        if (!mysql_num_rows( $result ))
            return FALSE;
        
        $details = mysql_fetch_array( $result, MYSQL_ASSOC );
        
        if (strlen( $details['geo_blocking'] )) {
            /* Block request */
            $countries = explode(',', $details['geo_blocking']);
            
            $arr = array();
            foreach ($countries as $country) {
                if ( strlen( $country = trim( $country ) ) )
                    $arr[] = strtolower( $country );
            }
            
            
            if ( count( $arr ) ) {
    
                header('X-CDN-AllowedCountries: '. implode( ',', $arr ));
            
                require_once "cdn-mod-geoblock.php";
                
                $client_ip = OneDB_RemoteAddr();
                $client_country = OneDB_Ip2Country( $client_ip );
                
                header('X-CDN-ClientCountryCode: '. $client_country );
                
                if (!in_array( $client_country, $arr ) ) {
                    
                    header('HTTP/1.1 403 Forbidden');
                    header('Content-Type: text/plain');
                    die("You are not allowed to view this content because it is geoBlocked!");
                }
            
            }
        }
        
        if (!file_exists( $details['file'] ) )
            return FALSE;
        
        $remoteURL = $details['url'];
        
        $info = parse_url( $remoteURL );
        
        $loopbackURL = str_replace( $info['host'], $_SERVER['SERVER_NAME'], $remoteURL, $replaces );
        
        if ($replaces != 1)
            return FALSE;
        
        $loopbackParts = explode( '/', $loopbackURL );
        $loopbackParts = implode('/', array_slice( $loopbackParts, 0, count( $loopbackParts ) - 1 ) );
        
        $fileName = end( explode( DIRECTORY_SEPARATOR, $details[ 'file'] ) );
        
        $loopbackGuessURL = $loopbackParts . '/' . $fileName;
        
        $parts = explode('?', $requestURI);

        if (count( $parts ) > 1) {
            $loopbackGuessURL .= '?' . implode( '?', array_slice( $parts, 1 ) ) . '&NO-LOOP=1';
        } else {
            $loopbackGuessURL .= '?NO-LOOP=1';
        }
        
        $handle = @fopen( $loopbackGuessURL, 'r' );
        if ( !is_resource( $handle ) ) return FALSE;
        
        foreach ($http_response_header as $h)
            header( $h );
        
        header('X-CDN-Loopback: TRUE');
        
        while (!feof( $handle )) {
            $buff = @fread( $handle, 8192 );
            if ( $buff !== FALSE)
                echo $buff;
        }
        
        @fclose( $handle );
        die('');
    }

    function serveRequest( $REQUEST_URI ) /* use ($CDN_SKIP_CONTENT_TYPES) */ {
    
        $originalRequestUri = $REQUEST_URI;
        
        global $CDN_SKIP_CONTENT_TYPES;
    
        $remoteURL = stripQueryParameters( CDN_MASTER . $REQUEST_URI );

        if (preg_match('/.php$/i', $remoteURL))
            error('403', 'Forbidden', 'File type not allowed on cdn server!');

        serveGeoBlockedUrl( $remoteURL, $originalRequestUri );

        /* Obtain the path information from $REQUEST_URI */
        $uInfo = @parse_url( $REQUEST_URI );
        $fInfo = @pathinfo( $uInfo['path'] );

        $localDir = @trim( $fInfo['dirname'], '/' );
        $localFile= @$fInfo['basename'];

        if (!strlen( $localDir ) || !strlen($localFile )) {
            if (strlen($localDir) + strlen($localFile) == 0) {
                require_once $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . "index.php";
                return;
            }
            error('400', 'Bad Request', "localDir = '$localDir' / localFile = '$localFile'");
        }

        // file_put_contents( '/tmp/cdn_request.log', $remoteURL . "\n", FILE_APPEND );

        $handle = @fopen( $remoteURL, 'r', false, stream_context_create( array(
            'http' => array(
                'method' => 'GET',
                'header' => "X-Forwarded-For: " . get_ip_address() . "\r\n"
            )
        ) ) );

        if (!is_resource( $handle ) ) {
            error( '404', 'Not Found');
        }
        
        registerShutdownCloseFile( $handle );
        
        $contentType = 'text/html';
        
        $CDNSkip = FALSE;
        $GEOBlock= FALSE;
        $LocalFilePrefix = '';
        
        /* Obtain the content-Type */
        foreach ($http_response_header as $line) {
            if (preg_match('/^Content-Type: ([^*]+)$/', $line, $matches)) {
                $contentType = $matches[1];
            }
            
            if (preg_match('/^X-CDN-Skip: TRUE$/i', $line)) {
                $CDNSkip = TRUE;
                header( $line );
            }
            
            if (preg_match('/^X-CDN-GeoBlocking: ([^*]+)/i', $line, $matches)) {
                $GEOBlock = $matches[1];
                header( $line );
            }
        }
        
        if ($GEOBlock !== FALSE) {
            $CDNSkip = FALSE;
            $LocalFilePrefix = CDN_GEOBLOCK_SECRET_KEY;
        }
        
        /* Check if the content type of the resource is disallowed
           in $CDN_SKIP_CONTENT_TYPES */
        
        foreach ($CDN_SKIP_CONTENT_TYPES as $cType) {
            if (preg_match( $cType, $contentType))
                error('415', 'Unsupported Media Type', $contentType . var_export( $http_response_header ) );
        }
        
        /* Create the directory structure on the Disk */
        $dirParts = explode('/', $localDir );
        $baseDir  = $_SERVER['DOCUMENT_ROOT'] ;
        
        /* Create the directory structure on the disk if it does not exist */
        
        foreach ($dirParts as $part ) {

            if ($part == '..')
                error('403', 'Forbidden', 'Illegal local path detected');
            
            $baseDir .= "/$part";
            //$baseDir = str_replace('//', '/', $baseDir );
            
            if (!is_dir( $baseDir )) {

                $mk = @mkdir( $baseDir );

                if ($mk === FALSE) {
                    error('500', 'Internal Server Error', 'Failed to create directory: ' . $part . ' (' . $baseDir . ')' );
                }
            }
        }
        
        $localStoreFile = str_replace('//', '/', $baseDir . "/$LocalFilePrefix$localFile");

        /* Ok, the directory structure is created, download the file */
    
        if (!$CDNSkip) {

            $localHandle = @fopen( $localStoreFile, 'w');
        
            if (!is_resource( $localHandle ))
                error('500', 'Internal Server Error', 'Could not create cache file on disk (' . $localStoreFile . ')' );
        
            registerShutdownCloseFile( $localHandle );
        }
        
        header("Content-Type: $contentType");
        
        while (!feof( $handle )) {
            $buffer = fread( $handle, 8192 );

            if ($buffer !== FALSE) {

                if (!$CDNSkip)
                    fwrite( $localHandle, $buffer, strlen($buffer ) );

                //Also dump request to client in the same time
                if ($CDNSkip)
                    echo $buffer;
            }
        }
        
        if (!$CDNSkip && preg_match('/.(mp4|m4v|m4a)$/i', $localStoreFile) ) {
            fclose( $localHandle );
            $cmd = QT_FASTSTART . ' ' . escapeshellarg( $localStoreFile );
            $result = `$cmd`;
            file_put_contents( dirname(__FILE__) . "/qtfaststart.log", "qtfaststart $localStoreFile\n" . $result . "\n\n", FILE_APPEND );
        }
        
        if (!$CDNSkip && preg_match('/.(flv)$/i', $localStoreFile) ) {
            fclose( $localHandle );
            $cmd = FLVTOOL2 . ' -U ' . escapeshellarg( $localStoreFile );
            $result = `$cmd`;
            file_put_contents( dirname(__FILE__) . "/flvtool2.log", "flvtool2 -U $localStoreFile\n" . $result . "\n\n", FILE_APPEND );
        }
        
        /* Insert the file into database, in order to be deleted later */
        

        if (!$CDNSkip) {
            $sql = "INSERT IGNORE INTO cdn ( url, file, geo_blocking ) VALUES ('" . mysql_escape_string( $remoteURL ) . "', '" . mysql_escape_string( $localStoreFile ) . "', '" . ( $GEOBlock === NULL ? 'NULL' : mysql_escape_string( $GEOBlock ) ) . "')";
            $result = @mysql_query( $sql );

            if (!$result) {
                fclose( $localHandle );
                unlink( $localStoreFile );
            }
        }

        /* File was downloaded, redirect client to the file again */
        if (!$CDNSkip) {
            // fclose( $localHandle );
            header("Location: $originalRequestUri");
        }
        
    }

?>