<?php
    
    $index     = isset( $_GET['index'] ) ? $_GET['index'] : die("Which index?");
    $operation = isset( $_GET['operation'] ) ? $_GET['operation'] : die("Which operation?");
    $_id       = isset( $_GET['_id'] ) ? $_GET['_id'] : die("Which ID?");
    
    if (!preg_match('/^[a-z0-9_]+$/i', $index ))
        die("Bad index name!");
    
    if (!preg_match('/^(create|update|delete)$/', $operation ))
        die("Unsupported operation!");
    
    if (!preg_match('/^[a-f0-9]+$/i', $_id))
        die("Bad _id!");
        
    $conf = @json_decode(
        file_get_contents(
            dirname(__FILE__) . '/config.json'
        ),
        TRUE
    );
    
    if (!is_array( $conf ))
        die("Bad config.json file!");
    
    $conn = mysql_connect( $conf['mysql']['host'], $conf['mysql']['user'], $conf['mysql']['password'] )
        or die("Cannot connect to batch mysql server!");
    
    $db = mysql_select_db( $conf['mysql']['database'], $conn ) or die("Cannot select database server!");
    
    $sql = "INSERT IGNORE INTO queue (`index`, `_id`, `operation`) VALUES ('$index', '$_id', '$operation')";
    $result = mysql_query( $sql ) or die("Database error: " . mysql_error());
    
    echo json_encode( array(
        'ok' => TRUE,
        'id' => mysql_insert_id() 
        )
    );
?>