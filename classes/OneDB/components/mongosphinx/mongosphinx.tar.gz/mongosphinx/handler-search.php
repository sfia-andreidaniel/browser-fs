<?php
    
    ini_set( 'display_errors', 'on');
    header('Access-Control-Allow-Origin: *');
    header('Content-Type: text/json');
      
    
    $q = isset( $_REQUEST['q'] ) ? $_REQUEST['q'] : die(
      json_encode(array(
        'error' => 'Missing query'
      ))
    );
    
    $limit = isset( $_REQUEST['limit'] ) ? $_REQUEST['limit'] : '20';
    
    if (!preg_match('/[1-9]([\d]+(,[1-9]([\d]+)?)?)?$/', $limit))
      die(json_encode(
        array(
          'error' => 'Bad limit'
        )
      ));
    
    $weights = isset( $_REQUEST['weights'] ) ? $_REQUEST['weights'] : array();
    
    if (!is_array( $weights ))
      die( json_encode( array(
        'error' => 'Weights should be an array'
      ) )
    );
    
    foreach ( array_keys( $weights ) as $field )
      if (!is_numeric( $weights[ $field ] ) )
        die( json_encode(
          array(
            'error' => 'Weight field ' . $field . ' should be numeric'
          )
        ) );
    
    require_once "etc/OneDB.inc.php";
    require_once "classes/MongoSphinx.class.php";
    require_once "classes/MongoIndex.class.php";
    
    /* Prepare the interogation */
    $q = OneDB_toAscii( $q );
    
    $q = preg_replace('/[^a-z0-9\-\_\|\@\"]+/i', ' ', $q);
    $q = trim( preg_replace('/^[\s]+$/', ' ', $q) );
    
    $index = $indexStr = isset( $_GET['index'] ) ? $_GET['index'] : die("Which index?");
    
    try {
      
      $my = new MongoSphinx( dirname(__FILE__) . "/config.json" );
      $index = $my->index( $index );
      
      $conn = $index->sphinx_connect();
      
      $sql = "SELECT * FROM `$indexStr` WHERE MATCH('$q') ORDER BY @weight DESC LIMIT $limit";
      
      if (count($weights)) {
        $w2 = array();
        foreach (array_keys( $weights ) as $field) {
          $w2[] = $field . '=' . $weights[$field];
        }
        $sql .= ' OPTION field_weights=(' . implode(', ', $w2 ) . ')';
      }
      
      $result = mysql_query( $sql, $conn );
      if (!$result)
        throw new Exception("Query error: " . mysql_error( $conn ) );
        
      $out = array();
      
      while ($row = mysql_fetch_array( $result, MYSQL_ASSOC ))
        $out[] = $row['_id'];
      
      echo json_encode( $out );
      
    } catch (Exception $e) {
      die( json_encode( array(
        'error' => $e->getMessage()
      ) ) );
    }
    
?>