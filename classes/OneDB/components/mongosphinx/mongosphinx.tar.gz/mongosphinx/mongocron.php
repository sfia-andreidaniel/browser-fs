#!/usr/bin/php
<?php

    chdir( dirname(__FILE__) );

    require_once "classes/MongoSphinx.class.php";
    require_once "classes/MongoIndex.class.php";
    
    $my = new MongoSphinx( dirname(__FILE__) . DIRECTORY_SEPARATOR . 'config.json' );
    
    /* Check if daemon is running, if not running, start it */
    
    if (!$my->searchd_pid()) {
        
        $my->searchd_start();
        
        if (!$my->searchd_pid())
            die("FATAL: searchd not running!");
        
    }
    
    /* Obtain the list of tasks */
    
    $conn = $my->mysql_connect();
    
    $sql = "SELECT * FROM queue ORDER BY id ASC LIMIT 500";
    $result = mysql_query( $sql, $conn ) or die("FATAL: MySQL ERROR: $sql\n");
    
    $jobs = array();
    while ($row = mysql_fetch_array( $result, MYSQL_ASSOC ))
        $jobs[] = $row;
    
    foreach ($jobs as $job) {
    
        echo '#', $job['id'], ': ', $job['index'], ".$job[operation]( $job[_id] )";
        
        try {
            
            $index = $my->index($job['index']);
            
            if ($job['operation'] != 'delete') {
            
                $cursor = $index->find( array(
                    '_id' => new MongoId( $job['_id'] )
                ));
            
                echo '[ ', $cursor->count(),' ]: ';
            
                while ($cursor->hasNext()) {
                    $data = $index->getNext( $cursor );
                    switch ( $job['operation'] ) {
                        case 'update':
                            if (!$index->replace( $data ))
                                throw new Exception("Error replacing!");
                            echo "ok ";
                            break;
                        case 'create':
                            if (!$index->insert( $data ))
                                throw new Exception("Error creating!");
                            echo "ok ";
                            break;
                        case 'upsert':
                            if (!$index->insert( $data )) {
                                if (!$index->replace( $data ))
                                    throw new Exception("Error upserting!");
                            }
                            echo "ok ";
                            break;
                        default:
                            throw new Exception("Invalid operation: $job[operation]");
                            break;
                    }
                }
            } else {
                if ($index->delete( $job['_id'] )) {
                    echo ": ok ";
                } else
                    throw new Exception(": Error deleting!");
            }
            
        } catch (Exception $e) {
            echo 'EXCEPTION: ', $e->getMessage();
        }
        
        echo "\n";
        
        if (!mysql_query($sql = "DELETE FROM queue WHERE id=$job[id] LIMIT 1", $conn))
            die("FATAL: MySQL ERROR: $sql\n");
    }

?>