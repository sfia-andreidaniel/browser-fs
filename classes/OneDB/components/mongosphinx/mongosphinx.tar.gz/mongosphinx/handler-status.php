<?php
    
    header('Access-Control-Allow-Origin: *');
    
    require_once "classes/MongoSphinx.class.php";
    require_once "classes/MongoIndex.class.php";
    
    // ini_set( 'display_errors', 'on');
    
    $index = $indexStr = isset( $_GET['index'] ) ? $_GET['index'] : die("Which index?");
    
    try {
      
      $my = new MongoSphinx( dirname(__FILE__) . "/config.json" );
      
      $index = $my->index( $index );
      
      $out = array(
        'pid' => $my->searchd_pid(),
        'id'  => $index->id( FALSE ),
        'tasks' => 0,
        'logs' => @trim( implode( "\n", array_slice( array_reverse( explode("\n", file_get_contents( 'sphinx/log/searchd.log' ) ) ) , 0, 20 ) ) )
      );
      
      $sql = "SELECT COUNT(*) FROM queue";
      $result = mysql_query( $sql, $my->mysql_connect() );
      
      if (!$result)
        throw new Exception( mysql_error(), $my->mysql_connect() );
      
      list( $out['tasks'] ) = mysql_fetch_row( $result );
      
      die( json_encode( $out ) );
      
    } catch (Exception $e) {
      die( json_encode( array(
        'error' => $e->getMessage()
      ) ) );
    }
    
?>