<?php

    require_once "etc/OneDB.inc.php";

    class MongoIndex {
        
        /**
         * {
         *
         *    "mongo_connection": {
         *        "host"       : "mongo1.bucuresti.rcs-rds.ro",
         *        "database"   : "digisport",
         *        "collection" : "articles",
         *        "user"       : "user",
         *        "password"   : "password"
         *    },
         *
         *    "auto_increment": 1,
         *
         *    "where": {
         *        "type": "Document",
         *        "online": true
         *    },
         *
         *    "fields": {
         *        "title": 1,
         *        "textContent": 1
         *    }
         *
         * }
         **/
        protected $_properties = array();
        
        
        protected $_parent = NULL;
        protected $_name = NULL;
        
        private $_collection = NULL;
        private $_sphinx = NULL;
        
        public function __construct( $indexName, $indexConfig, &$parentClass ) {
            $this->_parent = $parentClass;
            $this->_properties = $indexConfig;
            $this->_name = $indexName;
            // if (SAPI == 'cli')
            //    echo "* indexcfg: $indexName\n";
        }
        
        public function id( $increment = TRUE ) {
            if ($increment == TRUE) {
              $sql = "UPDATE indexes SET value = value + 1 WHERE name = '$this->_name'";
              $result = mysql_query( $sql, $this->_parent->mysql_connect() );
              if (!$result)
                  throw new Exception("Could not get auto_increment for this index! ($sql) " . mysql_error( $this->_parent->mysql_connect() ));
            }
            $sql = "SELECT value FROM indexes WHERE name = '$this->_name' LIMIT 1";
            $result = mysql_query( $sql, $this->_parent->mysql_connect() );
            if (!$result)
                throw new Exception("Could not get auto_increment for this index! ($sql) " . mysql_error( $this->_parent->mysql_connect() ));
            if (!mysql_num_rows( $result ))
                throw new Exception("Index not found in mysql!");
            list( $value ) = mysql_fetch_row( $result );
            return $value;
        }
        
        public function rt_fields() {
            return isset( $this->_properties['fields'] ) ? array_diff( array_keys( $this->_properties['fields'] ), array( '_id' ) ) : array();
        }
        
        /* Returns a new MongoCollection, based on $this->_properties['mongo_connection'] object */
        public function connect() {
        
            if ($this->_collection === NULL) {
        
                $con  = new Mongo( $this->_properties['mongo_connection'][ 'host' ] );
                $db   = $con->selectDB( $this->_properties['mongo_connection'][ 'database' ] );
                $auth = $db->authenticate( $this->_properties['mongo_connection'][ 'user'], $this->_properties['mongo_connection']['password'] );
                if (!is_array( $auth ) || !isset( $auth['ok'] ) || $auth['ok'] != 1)
                    throw new Exception("Cannot authenticate to mongo source $this->_name");
                $collection = $this->_properties[ 'mongo_connection' ]['collection'];

                $this->_collection = $db->{"$collection"};
            }
            
            return $this->_collection;
        }
        
        public function find( $optionalWhere = NULL ) {
            
            $where = isset( $this->_properties['where'] ) ? $this->_properties['where'] : array();
            
            if ($optionalWhere !== NULL && is_array( $optionalWhere )) {
                foreach (array_keys( $optionalWhere ) as $addKey ) {
                    $where[ $addKey ] = $optionalWhere[ $addKey ];
                }
            }
            
            $fields= isset( $this->_properties['fields']) ? $this->_properties['fields'] : array();
            
            $fields['_id'] = 1;
            $fields['_sphinxID'] = 1;
            
            return $this->connect()->find( $where, $fields );
        }
        
        public function getNext( &$mongoCursor, $FORCE_REINDEX = FALSE ) {
            $row = $mongoCursor->getNext();

            if ( !isset( $row['_sphinxID'] ) || $FORCE_REINDEX ) {
            
                $row['_sphinxID'] = $this->id();
                
                /* We do a row update */
                
                $this->_collection->update(
                    array(
                        "_id" => $row['_id']
                    ),
                    array(
                        '$set' => array(
                            '_sphinxID' => $row['_sphinxID']
                        )
                    ),
                    array(
                        'upsert' => true,
                        'multiple' => false,
                        'safe' => true
                    )
                );

            }
            
            return $row;
        }
        
        public function toObject() {
            return $this->_properties;
        }
        
        /* Returns a mysql connection handle to sphinx */
        public function sphinx_connect( $FORCE = FALSE ) {
            if ($this->_sphinx === NULL || $FORCE ) {
                $this->_sphinx = mysql_connect( '127.0.0.1:9306' );
                if (!$this->_sphinx)
                    throw new Exception("Cannot connect to sphinx on localhost:9306");
            }
            return $this->_sphinx;
        }
        
        public function insert( $MongoDBRow ) {
            /* First of all, we should do some mappings. 
             * MongoDBRow[ '_sphinxID' ] is actually the 'id' of the sphinx.
             * MongoDBRow[ '_id' ] is actually the data from the sphinx
             */
             
             $mappings = array();
             
             $_sphinxID = false;
             $_id       = false;
             
             foreach (array_keys( $MongoDBRow ) as $key) {
                switch ( $key ) {
                    case '_sphinxID':
                        $mappings[ '`id`' ] = (int)$MongoDBRow[ '_sphinxID' ];
                        $_sphinxID = TRUE;
                        break;
                    case '_id':
                        $mappings[ '`_id`' ] = "'" . mysql_escape_string( $MongoDBRow[ '_id' ] . '' ) . "'";
                        $_id = TRUE;
                        break;
                    default:
                        $mappings[ "`$key`" ] = "'" . mysql_escape_string( OneDB_toAscii( ( is_array( $MongoDBRow[ $key ] ) ? implode(', ', $MongoDBRow[ $key ] ) : $MongoDBRow[ $key ] ) . '' ) ) . "'";
                        break;
                }
             }
             
             if (!$_sphinxID || !$_id)
                throw new Exception("Fatal: Tried to insert a row which does not have _sphinxID or _id keys defined!");
             
             $sql = "INSERT INTO $this->_name (" . implode( ',', array_keys( $mappings ) ) . ") VALUES (" . implode(', ', array_values( $mappings ) ) . ")";
             $result = mysql_query( $sql, $this->sphinx_connect() );
             if ($result)
                return TRUE;
            else {
                // echo mysql_error(), "\n\n $sql \n\n";
                return FALSE;
            }
        }

        public function replace( $MongoDBRow ) {
            /* First of all, we should do some mappings. 
             * MongoDBRow[ '_sphinxID' ] is actually the 'id' of the sphinx.
             * MongoDBRow[ '_id' ] is actually the data from the sphinx
             */
             
             $mappings = array();
             
             $_sphinxID = false;
             $_id       = false;
             
             foreach (array_keys( $MongoDBRow ) as $key) {
                switch ( $key ) {
                    case '_sphinxID':
                        $mappings[ '`id`' ] = (int)$MongoDBRow[ '_sphinxID' ];
                        $_sphinxID = TRUE;
                        break;
                    case '_id':
                        $mappings[ '`_id`' ] = "'" . mysql_escape_string( $MongoDBRow[ '_id' ] . '' ) . "'";
                        $_id = TRUE;
                        break;
                    default:
                        $mappings[ "`$key`" ] = "'" . mysql_escape_string( $MongoDBRow[ $key ] . '' ) . "'";
                        break;
                }
             }
             
             if (!$_sphinxID || !$_id)
                throw new Exception("Fatal: Tried to insert a row which does not have _sphinxID or _id keys defined!");
             
             $sql = "REPLACE INTO $this->_name (" . implode( ',', array_keys( $mappings ) ) . ") VALUES (" . implode(', ', array_values( $mappings ) ) . ")";
             $result = mysql_query( $sql, $this->sphinx_connect() );
             if ($result)
                return TRUE;
            else {
                // echo mysql_error(), "\n\n $sql \n\n";
                return FALSE;
            }
        }
        
        public function delete( $sphinxPrimaryKey ) {
            $sql = "DELETE FROM $this->_name WHERE id = $sphinxPrimaryKey";
            $result = mysql_query( $sql, $this->sphinx_connect() );
            return $result ? TRUE : FALSE;
        }
        
        /* Don't use this command yet, it is a feature in the trunk version as beta only */
        public function truncate() {
            $hdl = scandir( dirname(__FILE__) . "/../sphinx/data/" );
            
            $this->_parent->searchd_stop();

            foreach ($hdl as $file) {
                if (substr( $file, 0, strlen( $this->_name ) + 1 ) == $this->_name . '.') {
                    @unlink( dirname(__FILE__) . "/../sphinx/data/$file" );
                    if (SAPI == 'cli')
                        echo "  -> rm sphinx/data/$file\n";
                }
            }
            
            $this->_parent->searchd_start();
        }
        
        public function build_initial_index() {
            
            // if (!$this->truncate()) {
            //     throw new Exception( "Failed to truncate index $this->_name! " . mysql_error() );
            // }
            
            $cursor = $this->find();
            
            $inserts= 0;
            
            while ( $cursor->hasNext() ) {
                $data = $cursor->getNext( $cursor, TRUE );
                
                $r = mysql_query(
                    $sql = "INSERT INTO queue ( `index`, `_id`, `operation`) VALUES ( '$this->_name', '$data[_id]', 'upsert' )",
                    $conn = $this->_parent->mysql_connect()
                );
                
                if (!$r)
                    throw new Exception("Cannot upsert: " . mysql_error( $conn ) . "\n");
                else
                    $inserts++;
            }
            
            if (SAPI == 'cli')
                echo "$inserts upserts\n";
        }
    }

?>