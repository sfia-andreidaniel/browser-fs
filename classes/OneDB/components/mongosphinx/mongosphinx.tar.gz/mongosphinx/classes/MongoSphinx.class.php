<?php

    define('SAPI', php_sapi_name());

    class MongoSphinx {
        
        public $_data = array();
        protected $_configFile = NULL;
        
        private $_mysql = NULL;
        
        function __construct( $configFile ) {
        
            $data = @json_decode( file_get_contents( $configFile ), TRUE );
            
            if (!is_array( $data )) {
                throw new Exception("Bad configuration file ($configFile)");
            }
            
            $this->_configFile = $configFile;
            
            $this->_data = $data;
            
            $this->_data['indexes'] = isset( $this->_data['indexes'] ) ? $this->_data['indexes'] : array();
            
            foreach (array_keys( $this->_data['indexes'] ) as $indexName) {
                $this->_data['indexes'][ $indexName ] = new MongoIndex( $indexName, $this->_data['indexes'][ $indexName ], $this );
            }
        }
        
        public function mysql_connect() {
            if ($this->_mysql === NULL) {
                $this->_mysql = mysql_connect( $this->_data['mysql']['host'], $this->_data['mysql']['user'], $this->_data['mysql']['password'] );

                if (!$this->_mysql)
                    throw new Exception("Could not connect to mysql server!");

                $db = mysql_select_db( $this->_data['mysql']['database'], $this->_mysql);

                if (!$db)
                    throw new Exception("Could not select mysql database!");
            }
            return $this->_mysql;
        }
        
        public function index( $indexName ) {
            if (!isset( $this->_data['indexes'][ "$indexName" ] ) )
                throw new Exception("Invalid index name: $indexName");
            
            return $this->_data['indexes']["$indexName"];
        }
        
        public function addIndex( $indexName, $indexConfig ) {
            
            $conn = mysql_connect();
            
            if (isset( $this->_data['indexes'][ $indexName ]) )
                throw new Exception("Could not add index: Index allready exists!");
                
            /* Prepare index in mysql */
            $sql = "INSERT INTO indexes ( name, value ) VALUES ( '" . mysql_escape_string( $indexName ) . "', 0 )";
            $result = mysql_query( $sql, $conn );
            
            if (!$result)
                throw new Exception("Could not add index in mysql: " . mysql_error( $conn ));
                
            $this->_data['indexes'][ $indexName ] = new MongoIndex( $indexName, $indexConfig, $this );
        }
        
        public function deleteIndex( $indexName ) {
            
            if (!isset( $this->_data['indexes'][ $indexName ] ))
                throw new Exception("Index does not exist!");
            
            $sql = "DELETE FROM indexes WHERE name = '" . mysql_escape_string( $indexName ) . "' LIMIT 1";
            $result = mysql_query($sql, $this->mysql_connect());
            
            if (!$result)
                throw new Exception( "Could not delete index counter from mysql!" );
            
            unset( $this->_data[ 'indexes'][ $indexName ] );
        }
        
        public function __destruct() {
            if ($this->_configFile !== NULL) {

                foreach ( array_keys( $this->_data['indexes'] ) as $indexName ) {
                    $this->_data['indexes'][ $indexName ] = $this->_data['indexes'][ $indexName ]->toObject();
                }
                
                require_once dirname(__FILE__) . '/../etc/json.php';

                $cfgStr = indent( json_encode( $this->_data ) );
                file_put_contents( $this->_configFile, $cfgStr );
                // if (SAPI == 'cli')
                //    echo "* shutdown: saved configuration\n";
            }
        }
        
        /* Builts a configuration file for the searchd server */
        public function searchd_configure( $tplData, $cfgFile ) {
            require_once "XTemplate.class.php";
            $tpl = new XTemplate( $tplData );
            
            $tpl->assign('CONFDIR', realpath( dirname(__FILE__) . '/../sphinx' ) );
            $tpl->assign('host', $this->_data['sphinx']['host']);
            $tpl->assign('port', $this->_data['sphinx']['port']);
            
            foreach (array_keys( $this->_data['indexes'] ) as $indexName ) {
                $tpl->assign('index', $indexName);
                
                /* parse index fields */
                
                foreach ( $this->_data['indexes'][ $indexName ]->rt_fields() as $fieldName) {
                    $tpl->assign('field_name', $fieldName);
                    $tpl->parse('main.index.field');
                }
                
                $tpl->parse('main.index');
            }
            
            $tpl->parse('main');
            
            file_put_contents( $cfgFile, $tpl->text( 'main' ));
            if (SAPI == 'cli')
                echo "* configuration file was built into $cfgFile\n";
        }
        
        /* Starts the searchd server */
        public function searchd_start() {
            if (!count( $this->_data['indexes'] ) ) {
                if (SAPI == 'cli')
                    echo "* searchd could not be started (no indexes were configured!)\n";
                return;
            }
            if (is_numeric( $searchdPid = $this->searchd_pid() )) {
                if (SAPI == 'cli')
                    echo '* searchd is allready running (PID = ' . $searchdPid . ")\n";
            } else {
                $cmd = $this->_data['sphinx']['searchd'] . ' -c ' . escapeshellarg( realpath( dirname(__FILE__) . '/../sphinx/sphinx.conf' ) );
                `$cmd`;
                if (SAPI == 'cli')
                    echo "* searchd lunched, (PID = " . $this->searchd_pid() . ")\n";
            }
        }
        
        /* Returns the process ID (PID) of the searchd server */
        public function searchd_pid() {
            $searchdPid = trim( @file_get_contents( dirname(__FILE__) . '/../sphinx/log/searchd.pid' ) . '' );
            return trim( $searchdPid );
        }
        
        /* Stops the searchd server */
        public function searchd_stop() {
            if (is_numeric( $searchdPid = $this->searchd_pid() )) {
                
                posix_kill( (int) $searchdPid, SIGTERM);
                
                if (SAPI == 'cli')
                echo "* sent SIGTERM to process: $searchdPid: ";
                
                $tries = 0;
                do {
                    if (SAPI == 'cli')
                        echo ".";
                    $tries++;
                    sleep( 1 );
                } while( $tries < 5 && file_exists( dirname(__FILE__) . '/../sphinx/log/searchd.pid' ) );
                
                if ( file_exists( dirname(__FILE__) . '/../sphinx/log/searchd.pid' ) ) {
                    if (SAPI == 'cli')
                        echo " FAILED\n";
                    return FALSE;
                } else {
                    if (SAPI == 'cli')
                        echo " OK\n";
                    return TRUE;
                }
            } else {
                if (SAPI == 'cli')
                    echo "* searchd is not running, so no SIGTERM was sent to any process!\n";
                return TRUE;
            }
        }
        
        /* Restarts the searchd server */
        public function searchd_restart() {
            if ($this->searchd_stop())
                $this->searchd_start();
        }
    }

?>