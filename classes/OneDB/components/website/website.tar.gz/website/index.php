<?php
    
    require_once "classes/XTemplate.class.php";
    require_once "conf/onedb.cfg.php";
    require_once "classes/OneDB/OneDB.class.php";
    require_once "classes/OneDB/frontend/SiteFrontend.class.php";

    $conn = new OneDB( );
    unset($conn);

    $frontend = new SiteFrontend("template/index.html", array(
        'HEADER',
        'BODY',
        'FOOTER'
    ));

    define('_FILE_', $_GET['_FILE_'] = isset( $_GET['_FILE_'] ) ? $_GET['_FILE_'] : '/' );
    
    try {
        $_PAGE_ = OneDB::get()->getElementByPath( _FILE_ );
    } catch (Exception $e) {
        $_PAGE_ = NULL;
    }

    require_once "_init.inc.php";

    switch (TRUE) {
        case empty($_PAGE_):
            require_once "notfound.php";
            break;

        case _FILE_ == '/':
            require_once "homepage.php";
            break;
        
        case substr(strrev( _FILE_ ), 0, 1) == '/':
            require_once "category.php";
            break;
        
        default:
            require_once "article.php";
            break;
    }

    require_once "_layout.inc.php";

    if (defined('POST_INCLUDE'))
        require_once POST_INCLUDE;

    $frontend->build();

    } catch (Exception $e) {
        echo "Error: ", $e->getMessage(),"<br />";
    }

?>