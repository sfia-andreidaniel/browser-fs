<?php

    /* Example of widget adding ...
    $frontend->FOOTER->add(
        CacheWidget(
            "widget://Google-Analytics", 86400,
            function() {
                return file_get_contents( dirname(__FILE__) . DIRECTORY_SEPARATOR . 'google-analytics.txt' );
            }
        ),
        'Google Analytics Snippet'
    );
    */

?>