<?php

    if (!isset($_SESSION))
        session_start();
    
    if (isset($_SESSION['CACHE.DISABLED']))
        unset($_SESSION['CACHE.DISABLED']);
    
    echo "cache enabled <br /><a href='disable-cache.php'>disable cache</a><br /><a href='/'>Website</a>";

?>