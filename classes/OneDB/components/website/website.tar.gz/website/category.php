<?php
    
    $frontend->BODY->add(
        '<h2>Category</h2>',
        'Content'
    );
    
    $frontend->BODY->add(
        $_PAGE_->views()->{"category.index"}->run(),
        "Category Default View"
    );
    
    $title = $_PAGE_->title;
    $name  = $_PAGE_->name;
    
    
    $description = $_PAGE_->description;
    if (!empty( $description ))
        $frontend->_PAGE_DESCRIPTION_ = htmlentities( $description, ENT_COMPAT, 'utf-8' );
    else 
        $frontend->_PAGE_DESCRIPTION_ = htmlentities( $name, ENT_COMPAT, 'utf-8' );
    
    $keywords = $_PAGE_->keywords;

    if (is_array( $keywords )) {
        for ($i=0; $i<count($keywords); $i++) {
            $keywords[$i] = htmlentities($keywords[$i], ENT_COMPAT, 'utf-8' );
        }
        $frontend->_PAGE_KEYWORDS_ = implode(', ', $keywords);
    } else $frontend->_PAGE_KEYWORDS_ = htmlentities( $name, ENT_COMPAT, 'utf-8' );
    
    
    $frontend->_PAGE_TITLE_ = empty( $title ) ? htmlentities( $name, ENT_COMPAT, 'utf-8' ) : htmlentities( $title, ENT_COMPAT, 'utf-8' );
?>