<?php

    if (!isset($_SESSION))
        session_start();
    
    $_SESSION['CACHE.DISABLED'] = TRUE;
    
    echo "cache disabled<br /><a href='enable-cache.php'>enable cache</a><br /><a href='/'>Website</a>";

?>