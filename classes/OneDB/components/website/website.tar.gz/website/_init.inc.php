<?php

    $frontend->addDependency('javascript', 'body', 'js/console.js');
    $frontend->addDependency('css', 'head', 'css/style.css');
    
    $frontend->_PAGE_TITLE_ = "My Site";
    

?>